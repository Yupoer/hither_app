// Print source context for failing assertions from a jest json report.
const fs = require('fs');
const report = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const before = Number(process.argv[3] ?? 6);
const after = Number(process.argv[4] ?? 2);
const strip = (s) => s.replace(/\u001b\[[0-9;]*m/g, '');
for (const suite of report.testResults) {
  for (const t of suite.assertionResults) {
    if (t.status !== 'failed') continue;
    const m = strip(t.failureMessages[0] ?? '');
    const loc = m.match(/__tests__[\\/]([\w.]+):(\d+):\d+/);
    if (!loc) { console.log('?? ' + suite.name + ' ' + t.title); continue; }
    const lines = fs.readFileSync(suite.name, 'utf8').split(/\r?\n/);
    const n = Number(loc[2]);
    console.log(`=== ${loc[1]}:${n} (${t.title})`);
    for (let i = Math.max(0, n - 1 - before); i < Math.min(lines.length, n + after); i++) {
      console.log(`${i + 1}${i + 1 === n ? '>' : ':'} ${lines[i]}`);
    }
  }
}
