const fs = require('fs');
const rwLines = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const lines = raw.replace(/\r\n/g, '\n').split('\n');
  fn(lines);
  fs.writeFileSync(p, lines.join('\n').replace(/\n/g, eol));
};
rwLines('src/__tests__/mapUiContracts.test.ts', (l) => {
  const i = l.findIndex((x) => x.startsWith('const carousel = '));
  l.splice(i + 1, 0,
    "const addPlaceCard = readFileSync(join(__dirname, '../screens/MapScreen/components/AddPlaceConfirmCard.tsx'), 'utf8');",
    "const routeEditorSheet = readFileSync(join(__dirname, '../screens/MapScreen/components/RouteEditorSheet.tsx'), 'utf8');");
});
const map = fs.readFileSync('src/screens/MapScreen.tsx', 'utf8');
const route = fs.readFileSync('src/screens/MapScreen/components/RouteEditorSheet.tsx', 'utf8');
rwLines('src/__tests__/routeReorderTour.test.ts', (l) => {
  const anchor = l.findIndex((x) => x.includes("expect(mapScreen).toContain('onOpenComplete={() => {');"));
  if (anchor < 0) throw new Error('anchor');
  for (let i = anchor; i < l.length && !/^\s*\}\);/.test(l[i]); i++) {
    const m = l[i].match(/^(\s*)expect\(mapScreen\)\.toContain\((.*)\);$/);
    if (!m) continue;
    // eslint-disable-next-line no-new-func
    const lit = Function(`return ${m[2]}`)();
    if (!map.includes(lit) && route.includes(lit)) l[i] = `${m[1]}expect(routeEditorSheet).toContain(${m[2]});`;
  }
  l.splice(anchor, 0, "    const routeEditorSheet = readFileSync(join(__dirname, '../screens/MapScreen/components/RouteEditorSheet.tsx'), 'utf8');");
});
console.log('ok');
