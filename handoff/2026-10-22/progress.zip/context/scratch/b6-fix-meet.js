const fs=require('fs');
const rw=(p,pairs)=>{const raw=fs.readFileSync(p,'utf8');const eol=raw.includes('\r\n')?'\r\n':'\n';let s=raw.replace(/\r\n/g,'\n');for(const [a,b] of pairs){if(!s.includes(a))throw new Error(p+' missing '+a);s=s.replace(a,b);}fs.writeFileSync(p,s.replace(/\n/g,eol));};
rw('src/__tests__/meetTimeEditor.test.ts',[
 ["const mockSetMeetTime = jest.fn(async () => undefined);","const mockSetMeetTime = jest.fn(async (..._args: unknown[]) => undefined);"],
 ["const mockCancel = jest.fn(async () => undefined);","const mockCancel = jest.fn(async (_id: string) => undefined);"],
 ["  setDestinationMeetTime: (...args: unknown[]) => mockSetMeetTime(...(args as [])),","  setDestinationMeetTime: (...args: unknown[]) => mockSetMeetTime(...args),"],
]);
rw('src/__tests__/mapUiContracts.test.ts',[["    expect(mapScreen).toContain('alignMeetTimeToTripDay');\n",""]]);
rw('src/__tests__/gatheringWorkflowContract.test.ts',[["    expect(mapScreen).toContain('if (!canEditItinerary) return;');","    expect(mapScreen).toContain('if (!groupId || !canEditItinerary) return;');"]]);