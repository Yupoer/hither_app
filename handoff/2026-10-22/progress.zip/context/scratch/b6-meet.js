const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const start = s.indexOf('  // --- Meet-time countdown + editor');
const endMarker = '  }, [meetTimeEditor]);\n';
const end = s.indexOf(endMarker, start) + endMarker.length;
if (start < 0 || end < endMarker.length) throw new Error('markers');
let block = s.slice(start, end).split('\n').slice(1).join('\n');
block = block.split('group?.departureDate').join('departureDate');
const hook = `import { useCallback, useEffect, useMemo, useState } from 'react';
import { DateTimePickerAndroid } from '@react-native-community/datetimepicker';
import { setDestinationMeetTime } from '../../../api/client';
import type { TranslationKey } from '../../../i18n';
import { notifications } from '../../../native';
import { DEFAULT_MEET_RED_MIN, MEET_RED_OPTIONS } from '../../../state/PreferencesContext';
import type { Destination } from '../../../types';
import { alertBuzz } from '../../../utils/haptics';
import { alignMeetTimeToTripDay, clampDateNotBeforeToday, startOfTodayLocal } from '../../../utils/meetTime';
import { getOperationErrorMessage } from '../../../utils/operationError';

export interface MeetTimeEditorState {
  id: string;
  value: Date;
  redMin: number;
  quickMinutes: number | null;
}

export interface UseMeetTimeEditorInput {
  /** Visible gathering points; the soonest future meet time gets local reminders. */
  destinations: Destination[];
  departureDate: string | null | undefined;
  canEditItinerary: boolean;
  meetRedMin: number;
  setMeetRedMin: (minutes: number) => void;
  refresh: () => Promise<unknown>;
  showOperationFailure: (title: string, message: string) => void;
  t: (key: TranslationKey, params?: Record<string, string | number>) => string;
}

/**
 * Meet-time countdown editor (date + time + shared red threshold) and the
 * device-side reminders for the soonest upcoming meet time.
 */
export function useMeetTimeEditor({
  destinations,
  departureDate,
  canEditItinerary,
  meetRedMin,
  setMeetRedMin,
  refresh,
  showOperationFailure,
  t,
}: UseMeetTimeEditorInput) {
${block.replace(/^  const \[meetTimeEditor, setMeetTimeEditor\] = useState<\{\n    id: string;\n    value: Date;\n    redMin: number;\n    quickMinutes: number \| null;\n  \} \| null>\(null\);/m,
  '  const [meetTimeEditor, setMeetTimeEditor] = useState<MeetTimeEditorState | null>(null);')}
  return { meetTimeEditor, setMeetTimeEditor, persistMeetTime, openMeetTimePicker, openAndroidMeetDate };
}
`;
if (!hook.includes('useState<MeetTimeEditorState | null>')) throw new Error('state decl not replaced');
fs.writeFileSync('src/screens/MapScreen/hooks/useMeetTimeEditor.ts', hook);
s = s.slice(0, start) + `  // --- Meet-time countdown + editor (date + time; red threshold shared via DB)
  const {
    meetTimeEditor,
    setMeetTimeEditor,
    persistMeetTime,
    openMeetTimePicker,
    openAndroidMeetDate,
  } = useMeetTimeEditor({
    destinations,
    departureDate: group?.departureDate,
    canEditItinerary,
    meetRedMin,
    setMeetRedMin,
    refresh,
    showOperationFailure,
    t,
  });
` + s.slice(end);
s = s.replace("import { useGatheringWorkflow }", "import { useMeetTimeEditor } from './MapScreen/hooks/useMeetTimeEditor';\nimport { useGatheringWorkflow }");
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok');
