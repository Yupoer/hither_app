const fs=require('fs');const p='src/__tests__/mapUiContracts.test.ts';const raw=fs.readFileSync(p,'utf8');const eol=raw.includes('\r\n')?'\r\n':'\n';let s=raw.replace(/\r\n/g,'\n');
const rep=(a,b)=>{if(!s.includes(a))throw new Error('missing '+a);s=s.replace(a,b);};
rep(`    const overlayRouteEnd = routeEditorSheet.indexOf('<SettingsOverlay', overlayRoute);
    const overlayBlock = routeEditorSheet.slice(
      overlayRoute,
      overlayRouteEnd > 0 ? overlayRouteEnd : overlayRoute + 3500,
    );`,`    const overlayBlock = routeEditorSheet.slice(overlayRoute);`);
rep(`    expect(mapScreen).not.toMatch(
      /showArrivalControl\\s*=\\s*[\\s\\S]{0,200}sharedTargetId === dest\\.id/,
    );
    const arriveBlocks = mapScreen.match(`,`    expect(mapScreen + carousel).not.toMatch(
      /showArrivalControl\\s*=\\s*[\\s\\S]{0,200}sharedTargetId === dest\\.id/,
    );
    const arriveBlocks = (mapScreen + carousel).match(`);
fs.writeFileSync(p,s.replace(/\n/g,eol));console.log('ok');