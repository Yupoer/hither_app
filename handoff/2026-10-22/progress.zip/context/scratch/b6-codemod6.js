﻿const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const rep = (a, b) => { const i = s.indexOf(a); if (i < 0) throw new Error('missing: ' + a.slice(0, 80)); s = s.slice(0, i) + b + s.slice(i + a.length); };
rep(`import { useGroupRole } from './MapScreen/hooks/useGroupRole';\n`, `import { useGroupRole } from './MapScreen/hooks/useGroupRole';
import {
  hasDraftWork,
  insertDraftDestination,
  nextOrderInDay,
  useRouteDraft,
} from './MapScreen/hooks/useRouteDraft';
import {
  applyReorderUpdates,
  persistedReorderUpdates,
  type ReorderUpdate,
} from './MapScreen/itineraryReorder';\n`);
rep(`const PASSIVE_ENTER_HEIGHT = 65; // round(162 * 0.4)\n`, `const PASSIVE_ENTER_HEIGHT = 65; // round(162 * 0.4)
const EMPTY_DESTINATIONS: Destination[] = [];\n`);
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
