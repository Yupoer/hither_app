const fs = require('fs');
const rw = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const out = fn(raw.replace(/\r\n/g, '\n'));
  if (out === raw.replace(/\r\n/g, '\n')) throw new Error('no change ' + p);
  fs.writeFileSync(p, out.replace(/\n/g, eol));
};
rw('src/screens/MapScreen/hooks/useSubgroupActions.ts', (s) => s.replace(
  "import type { GroupReloadReason } from '../../../state/useGroupState';\n", '').replace(
  "import { logError, logEvent } from '../../../utils/activityLog';\n",
  "import { logError, logEvent } from '../../../utils/activityLog';\n").replace(
  "import { mediumTap, selectionTick } from '../../../utils/haptics';\n",
  "import { mediumTap, selectionTick } from '../../../utils/haptics';\nimport type { GroupReloadReason } from '../../../utils/syncAuthority';\n"));
rw('src/screens/MapScreen.tsx', (s) => s.replace(
  "  const setRouteDraftDestinations = routeDraft.setDestinations;\n",
  `  const setRouteDraftDestinations = routeDraft.setDestinations;
  const handleMergedBack = useCallback(() => {
    // Leave wipes subgroup-scoped UI: itinerary draft list, team pill scope.
    setRouteDraftDestinations(null);
    setViewingScope('main');
  }, [setRouteDraftDestinations]);
`).replace(`    onMergedBack: useCallback(() => {
      // Leave wipes subgroup-scoped UI: itinerary draft list, team pill scope.
      setRouteDraftDestinations(null);
      setViewingScope('main');
    }, [setRouteDraftDestinations]),
`, '    onMergedBack: handleMergedBack,\n'));
console.log('ok');
