const fs = require('fs');
const T = 'src/__tests__/';
const rw = (name, pairs) => {
  const p = T + name;
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  let s = raw.replace(/\r\n/g, '\n');
  for (const [a, b] of pairs) {
    if (!s.includes(a)) throw new Error(`${name} missing: ${a}`);
    s = s.split(a).join(b);
  }
  fs.writeFileSync(p, s.replace(/\n/g, eol));
};
const comp = (file) => `readFileSync(join(__dirname, '../screens/MapScreen/components/${file}.tsx'), 'utf8')`;

rw('arrivalFeedbackContract.test.ts', [
  ['const cardKeyIdx = source.indexOf(cardKeyNeedle);', 'const cardKeyIdx = carousel.indexOf(cardKeyNeedle);'],
  ['const carouselCard = source.slice(cardKeyIdx, cardKeyIdx + 4000);', 'const carouselCard = carousel.slice(cardKeyIdx, cardKeyIdx + 4000);'],
]);
rw('mapStoreUxContracts.test.ts', [
  ['const addStart = mapScreen.indexOf("name: pendingPlaceTitle.trim() || pendingPlace.name");',
    'const addStart = addPlaceCard.indexOf("name: pendingPlaceTitle.trim() || pendingPlace.name");'],
]);
rw('mapChromeUiContract.test.ts', [
  ["    expect((map.match(/size=\\{36\\}/g) ?? [])).toHaveLength(2);",
    "    const arrivalSheets = read('screens/MapScreen/components/ArrivalManageSheet.tsx')\n      + read('screens/MapScreen/components/ArrivalTimeSheet.tsx');\n    expect((arrivalSheets.match(/size=\\{36\\}/g) ?? [])).toHaveLength(2);"],
]);
rw('nativeUiContracts.test.ts', [
  [`    const routeOverlay = mapScreen.slice(
      mapScreen.indexOf("visible={overlay === 'route'}"),
      mapScreen.indexOf('<GroupFeatureTourOverlay', mapScreen.indexOf("visible={overlay === 'route'}")),
    );`, `    const routeOverlay = routeEditorSheet.slice(routeEditorSheet.indexOf("visible={overlay === 'route'}"));`],
]);
rw('buttonInventoryContract.test.ts', [['const corpus = [\n      mapScreen,', 'const corpus = [\n      mapScreen,\n      addPlaceCard,']]);
rw('amicroUiContracts.test.ts', [
  ['expect(map + passive + refreshButton).toMatch(', 'expect(map + passive + refreshButton + carousel + routeEditorSheet + inviteMembersOverlay).toMatch('],
]);
rw('gatherRequestInbox.test.ts', [
  [`    const editorStart = map.indexOf("visible={overlay === 'route'}");
    expect(editorStart).toBeGreaterThan(-1);
    const editorEnd = map.indexOf('DestinationReorderList', editorStart);
    const editorBlock = map.slice(editorStart, editorEnd);`, `    const routeEditorSheet = ${comp('RouteEditorSheet')};
    const editorStart = routeEditorSheet.indexOf("visible={overlay === 'route'}");
    expect(editorStart).toBeGreaterThan(-1);
    const editorEnd = routeEditorSheet.indexOf('DestinationReorderList', editorStart);
    const editorBlock = routeEditorSheet.slice(editorStart, editorEnd);`],
]);
rw('keyboardSurface.test.ts', [
  ["const nameIdx = map.indexOf('testID=\"confirm-place-name\"');", "const nameIdx = addPlaceCard.indexOf('testID=\"confirm-place-name\"');"],
  ['expect(map.slice(Math.max(0, nameIdx - 900), nameIdx + 40)).toMatch(/TextInput/);', 'expect(addPlaceCard.slice(Math.max(0, nameIdx - 900), nameIdx + 40)).toMatch(/TextInput/);'],
]);
rw('mapUiContracts.test.ts', [
  [`    const confirmStart = mapScreen.indexOf('const confirmAddPlace = async');
    const confirmBlock = mapScreen.slice(confirmStart, confirmStart + 420);`, `    const confirmStart = addPlaceCard.indexOf('const confirmAddPlace = async');
    const confirmBlock = addPlaceCard.slice(confirmStart, confirmStart + 420);`],
  [`    const overlayRoute = mapScreen.indexOf("visible={overlay === 'route'}");
    const overlayRouteEnd = mapScreen.indexOf('<SettingsOverlay', overlayRoute);
    const overlayBlock = mapScreen.slice(`, `    const overlayRoute = routeEditorSheet.indexOf("visible={overlay === 'route'}");
    const overlayRouteEnd = routeEditorSheet.indexOf('<SettingsOverlay', overlayRoute);
    const overlayBlock = routeEditorSheet.slice(`],
  [`    const cardBodyStart = mapScreen.indexOf(
      '{cardExpanded ? (',
      mapScreen.indexOf('Collapsed / expanded swap in-tree'),
    );
    const cardBodyEnd = mapScreen.indexOf(') : (', cardBodyStart);`, `    const cardBodyStart = carousel.indexOf(
      '{cardExpanded ? (',
      carousel.indexOf('Collapsed / expanded swap in-tree'),
    );
    const cardBodyEnd = carousel.indexOf(') : (', cardBodyStart);`],
  [`    const commandRow = mapScreen.indexOf('styles.commandRow');
    const arrivalButton = mapScreen.indexOf('arrivalCmdSquare', commandRow);
    const meetButton = mapScreen.indexOf('styles.meetBtn', commandRow);`, `    const commandRow = carousel.indexOf('styles.commandRow');
    const arrivalButton = carousel.indexOf('arrivalCmdSquare', commandRow);
    const meetButton = carousel.indexOf('styles.meetBtn', commandRow);`],
  [`    const transportRef = mapScreen.indexOf("setTourTargetRef('transport'", commandRow);
    const meetRef = mapScreen.indexOf("setTourTargetRef('meetTime'", commandRow);`, `    const transportRef = carousel.indexOf("setTourTargetRef('transport'", commandRow);
    const meetRef = carousel.indexOf("setTourTargetRef('meetTime'", commandRow);`],
]);
rw('routeEditorKmlContract.test.ts', [
  ["const reorderStart = mapScreen.indexOf('visible={overlay === \\'route\\'}');", "const reorderStart = routeEditorSheet.indexOf('visible={overlay === \\'route\\'}');"],
  ['const reorderBlock = mapScreen.slice(reorderStart, reorderStart + 9000);', 'const reorderBlock = routeEditorSheet.slice(reorderStart, reorderStart + 9000);'],
]);
rw('groupFeatureTourHighlight.test.ts', [
  ["    const chipIdx = map.indexOf('styles.arrivalPeopleChip');\n    const arrivalRefIdx = map.indexOf(\"setTourTargetRef('arrivalProgress'\");",
    "    const chipIdx = carousel.indexOf('styles.arrivalPeopleChip');\n    const arrivalRefIdx = carousel.indexOf(\"setTourTargetRef('arrivalProgress'\");"],
]);
console.log('ok');
