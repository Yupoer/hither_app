// Outline JSX children of the last `return (` in MapScreen with line ranges.
const ts = require(require.resolve('typescript', { paths: [process.cwd()] }));
const fs = require('fs');
const file = process.argv[2] ?? 'src/screens/MapScreen.tsx';
const depth = Number(process.argv[3] ?? 2);
const text = fs.readFileSync(file, 'utf8');
const sf = ts.createSourceFile(file, text, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const line = (pos) => sf.getLineAndCharacterOfPosition(pos).line + 1;
let fn;
sf.forEachChild((n) => { if (ts.isFunctionDeclaration(n) && n.name?.text === 'MapScreen') fn = n; });
const returns = fn.body.statements.filter(ts.isReturnStatement);
const ret = returns[returns.length - 1];
const describe = (node) => {
  if (ts.isJsxElement(node)) return node.openingElement.tagName.getText(sf);
  if (ts.isJsxSelfClosingElement(node)) return node.tagName.getText(sf) + '/';
  if (ts.isJsxFragment(node)) return '<>';
  if (ts.isJsxExpression(node)) return '{' + (node.expression ? node.expression.getText(sf).slice(0, 50).replace(/\s+/g, ' ') : '') + '}';
  return ts.SyntaxKind[node.kind];
};
const walk = (node, d) => {
  const children = ts.isJsxElement(node) || ts.isJsxFragment(node) ? node.children : [];
  for (const c of children) {
    if (ts.isJsxText(c) && !c.getText(sf).trim()) continue;
    const a = line(c.getStart(sf));
    const b = line(c.getEnd());
    console.log(`${'  '.repeat(d)}${a}-${b} (${b - a + 1}) ${describe(c)}`);
    if (d + 1 < depth) walk(c, d + 1);
  }
};
let expr = ret.expression;
while (ts.isParenthesizedExpression(expr)) expr = expr.expression;
console.log(`root ${line(expr.getStart(sf))}-${line(expr.getEnd())} ${describe(expr)}`);
walk(expr, 0);
