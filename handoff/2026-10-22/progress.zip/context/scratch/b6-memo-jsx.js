// Print line ranges of JSX bodies returned by useMemo/useCallback arrow functions in MapScreen.
const ts = require(require.resolve('typescript', { paths: [process.cwd()] }));
const fs = require('fs');
const file = 'src/screens/MapScreen.tsx';
const sf = ts.createSourceFile(file, fs.readFileSync(file, 'utf8'), ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
const line = (pos) => sf.getLineAndCharacterOfPosition(pos).line + 1;
const visit = (n) => {
  if (ts.isVariableDeclaration(n) && n.initializer && ts.isCallExpression(n.initializer)
    && /^(useMemo|useCallback)$/.test(n.initializer.expression.getText(sf))) {
    const fnArg = n.initializer.arguments[0];
    if (fnArg && ts.isArrowFunction(fnArg)) {
      let body = fnArg.body;
      if (ts.isBlock(body)) {
        const ret = body.statements.filter(ts.isReturnStatement).pop();
        body = ret?.expression;
      }
      while (body && ts.isParenthesizedExpression(body)) body = body.expression;
      if (body && (ts.isJsxElement(body) || ts.isJsxFragment(body) || ts.isJsxSelfClosingElement(body))) {
        const a = line(body.getStart(sf));
        const b = line(body.getEnd());
        if (b - a > 15) console.log(`${n.name.getText(sf)} ${a} ${b} (${b - a + 1})`);
      }
    }
  }
  ts.forEachChild(n, visit);
};
visit(sf);
