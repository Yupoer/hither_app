const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
const raw = fs.readFileSync(p, 'utf8');
let s = raw.replace(/\r\n/g, '\n');
const rep = (a, b) => { const i = s.indexOf(a); if (i < 0) throw new Error('missing: ' + a.slice(0, 80)); if (s.indexOf(a, i + 1) >= 0) throw new Error('dup: ' + a.slice(0, 80)); s = s.slice(0, i) + b + s.slice(i + a.length); };
rep(`    const dirty = {
      destinations: routeDraftDirtyRef.current.destinations,
      daily: routeDraftDirtyRef.current.daily,
      trip: routeDraftDirtyRef.current.trip,
      deletedIds: [...routeDraftDirtyRef.current.deletedIds],
    };
    const hasWork =
      dirty.destinations
      || dirty.daily
      || dirty.trip
      || dirty.deletedIds.length > 0;
    if (!hasWork) {
      setOptimisticDestinations(null);
      setDraftDailyAccommodations(null);
      return;
    }`, `    const dirty = routeDraft.dirty();
    if (!hasDraftWork(dirty)) {
      routeDraft.setDestinations(null);
      routeDraft.setDaily(null);
      return;
    }`);
rep(`            let draftDests = optimisticDestinationsRef.current;`, `            let draftDests = routeDraft.latestDestinations();`);
rep(`                optimisticDestinationsRef.current = savedDests;
                setOptimisticDestinations(savedDests);
                if (draftDailyRef.current) {
                  draftDailyRef.current = draftDailyRef.current.map(row => row.sourceDestinationId === dest.id
                    ? { ...row, sourceDestinationId: newId } : row);
                  setDraftDailyAccommodations(draftDailyRef.current);
                }
                dirty.destinations = true;
                routeDraftDirtyRef.current.destinations = true;`, `                routeDraft.setDestinations(savedDests, { dirty: true });
                const draftDaily = routeDraft.latestDaily();
                if (draftDaily) {
                  routeDraft.setDaily(draftDaily.map(row => row.sourceDestinationId === dest.id
                    ? { ...row, sourceDestinationId: newId } : row));
                }
                dirty.destinations = true;`);
rep(`            if (dirty.daily && draftDailyRef.current) {`, `            const draftDaily = routeDraft.latestDaily();
            if (dirty.daily && draftDaily) {`);
rep(`                draftDailyRef.current.map((d) => [d.stayDate, d]),`, `                draftDaily.map((d) => [d.stayDate, d]),`);
rep(`            setOptimisticDestinations(null);
            setDraftDailyAccommodations(null);
            setOptimisticTripDays(null);
            setOptimisticDepartureDate(null);
            routeDraftDirtyRef.current = {
              destinations: false,
              daily: false,
              trip: false,
              deletedIds: [],
            };`, `            routeDraft.reset();`);
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok');
