// Move top-level declarations out of MapScreen.tsx into a new module and wire imports.
// Usage (cwd apps/mobile): node b6-extract.js <spec.json>
// spec: { "target": "src/screens/MapScreen/components/X.tsx",
//         "blocks": [["startLineText", "endLineText"]...],   // inclusive, first match each
//         "exports": ["Name", ...],                           // names exported + imported back
//         "defaultExport": "Name" (optional), "importBack": true|false }
// Imports for the new module are resolved from MapScreen's own import list for every
// identifier the moved code references; paths are rebased to the new module's folder.
const fs = require('fs');
const path = require('path');
const spec = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const mapPath = 'src/screens/MapScreen.tsx';
let src = fs.readFileSync(mapPath, 'utf8').replace(/\r\n/g, '\n');

// 1. Parse MapScreen imports: local name -> { from, kind, imported, typeOnly }.
const importRe = /^import (type )?([\s\S]*?) from (['"])([^'"]+)\3;\n/gm;
const bindings = new Map();
for (const m of src.matchAll(importRe)) {
  const typeAll = Boolean(m[1]);
  const clause = m[2];
  const from = m[4];
  const cm = clause.match(/^([A-Za-z_$][\w$]*)?\s*,?\s*(?:\{([\s\S]*)\})?\s*$/);
  const ns = clause.match(/^\*\s+as\s+(\w+)$/);
  if (ns) { bindings.set(ns[1], { from, kind: 'ns', typeOnly: typeAll }); continue; }
  if (!cm) continue;
  if (cm[1]) bindings.set(cm[1], { from, kind: 'default', typeOnly: typeAll });
  for (const spec of (cm[2] ?? '').split(',').map((x) => x.trim()).filter(Boolean)) {
    const typeOnly = typeAll || spec.startsWith('type ');
    const clean = spec.replace(/^type\s+/, '');
    const [imported, local] = clean.split(/\s+as\s+/).map((x) => x.trim());
    bindings.set(local ?? imported, { from, kind: 'named', imported, typeOnly });
  }
}

// 2. Cut the blocks.
const moved = [];
for (const [startText, endText] of spec.blocks) {
  const lines = src.split('\n');
  const start = lines.findIndex((l) => l === startText);
  if (start < 0) throw new Error('start not found: ' + startText);
  let end = lines.findIndex((l, i) => i >= start && l === endText);
  if (end < 0) throw new Error('end not found: ' + endText);
  // Pull a directly preceding JSDoc/comment block along.
  let docStart = start;
  while (docStart > 0 && /^(\/\*\*|\s\*|\s\*\/|\/\/)/.test(lines[docStart - 1])) docStart--;
  moved.push(lines.slice(docStart, end + 1).join('\n'));
  lines.splice(docStart, end + 1 - docStart);
  if (lines[docStart] === '' && lines[docStart - 1] === '') lines.splice(docStart, 1);
  src = lines.join('\n');
}
let body = moved.join('\n\n');
for (const name of spec.exports ?? []) {
  body = body.replace(new RegExp(`^(const|function|type|interface) ${name}\\b`, 'm'), `export $1 ${name}`);
}

// 3. Resolve identifiers the moved code uses.
const used = new Set(body.match(/\b[A-Za-z_$][\w$]*\b/g));
const targetDir = path.dirname(spec.target);
const rebase = (from) => {
  if (!from.startsWith('.')) return from;
  const abs = path.join(path.dirname(mapPath), from);
  let rel = path.relative(targetDir, abs).replace(/\\/g, '/');
  if (!rel.startsWith('.')) rel = './' + rel;
  return rel;
};
const byFrom = new Map();
for (const name of used) {
  const b = bindings.get(name);
  if (!b) continue;
  const key = rebase(b.from);
  if (!byFrom.has(key)) byFrom.set(key, { def: null, ns: null, named: [] });
  const entry = byFrom.get(key);
  if (b.kind === 'default') entry.def = name;
  else if (b.kind === 'ns') entry.ns = name;
  else entry.named.push(`${b.typeOnly ? 'type ' : ''}${b.imported === name ? name : `${b.imported} as ${name}`}`);
}
const order = [...byFrom.keys()].sort((a, b) => (a.startsWith('.') - b.startsWith('.')) || a.localeCompare(b));
const header = order.map((from) => {
  const e = byFrom.get(from);
  if (e.ns) return `import * as ${e.ns} from '${from}';`;
  const parts = [];
  if (e.def) parts.push(e.def);
  if (e.named.length) parts.push(`{ ${e.named.sort((x, y) => x.replace('type ', '').localeCompare(y.replace('type ', ''))).join(', ')} }`);
  return `import ${parts.join(', ')} from '${from}';`;
}).join('\n');
const extraHeader = spec.header ? spec.header + '\n' : '';
fs.writeFileSync(spec.target, `${header}\n${extraHeader}\n${body.trim()}\n${spec.defaultExport ? `\nexport default ${spec.defaultExport};\n` : ''}`);

// 4. Import back into MapScreen.
if (spec.importBack !== false && (spec.exports ?? []).length) {
  let rel = path.relative(path.dirname(mapPath), spec.target).replace(/\\/g, '/').replace(/\.tsx?$/, '');
  if (!rel.startsWith('.')) rel = './' + rel;
  const line = `import { ${spec.exports.join(', ')} } from '${rel}';\n`;
  const anchor = src.indexOf('import { useGroupRole }');
  src = src.slice(0, anchor) + line + src.slice(anchor);
}
fs.writeFileSync(mapPath, src.replace(/\n/g, '\r\n'));
console.log('moved', body.split('\n').length, 'lines to', spec.target);
