﻿const fs = require('fs');
const edit = (p, pairs) => { const raw = fs.readFileSync(p, 'utf8'); const eol = raw.includes('\r\n') ? '\r\n' : '\n'; let s = raw.replace(/\r\n/g, '\n'); for (const [a, b] of pairs) { if (!s.includes(a)) throw new Error(p + ' missing ' + a); s = s.replace(a, b); } fs.writeFileSync(p, s.replace(/\n/g, eol)); };
edit('src/screens/MapScreen.tsx', [[`import {
  buildOpenReorderPayload,
  mapOpenReorderToPersistedPositions,
  openPositionSlotsFromOpenDestinations,
} from '../utils/openReorderSlots';`, `import { buildOpenReorderPayload } from '../utils/openReorderSlots';`]]);
edit('src/__tests__/routeEditorKmlContract.test.ts', [[`    // Slot remap lives on applyReorderToDestinations (shared local + nav persist).
    expect(mapScreen).toContain('openPositionSlotsFromOpenDestinations');
    expect(mapScreen).toContain('mapOpenReorderToPersistedPositions');
`, '']]);
