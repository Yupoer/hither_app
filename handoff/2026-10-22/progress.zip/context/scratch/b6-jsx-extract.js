// Extract one JSX node of MapScreen's render into a typed component.
// Usage (cwd apps/mobile): node b6-jsx-extract.js <startLine> <endLine> <ComponentName> <targetFile> [--dry]
// The node is the JSX element / expression child that spans exactly startLine..endLine.
// Free locals become typed props (types printed by the checker), imports are copied
// and rebased, and the node is replaced by <ComponentName prop={prop} ... />.
const path = require('path');
const fs = require('fs');
const ts = require(require.resolve('typescript', { paths: [process.cwd()] }));
const [startLine, endLine, name, target, flag] = process.argv.slice(2);
const dry = flag === '--dry';
const mapFile = path.resolve('src/screens/MapScreen.tsx');
const cfgPath = path.resolve('tsconfig.json');
const cfg = ts.readConfigFile(cfgPath, ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(cfg.config, ts.sys, path.dirname(cfgPath));
const program = ts.createProgram({ rootNames: [mapFile], options: parsed.options });
const checker = program.getTypeChecker();
const sf = program.getSourceFile(mapFile);
const text = sf.getFullText();
const lineOf = (pos) => sf.getLineAndCharacterOfPosition(pos).line + 1;

let fn;
sf.forEachChild((n) => { if (ts.isFunctionDeclaration(n) && n.name?.text === 'MapScreen') fn = n; });
let found;
const visit = (n) => {
  if (found) return;
  if ((ts.isJsxElement(n) || ts.isJsxSelfClosingElement(n) || ts.isJsxExpression(n) || ts.isJsxFragment(n))
    && lineOf(n.getStart(sf)) === Number(startLine) && lineOf(n.getEnd()) === Number(endLine)) {
    found = n;
    return;
  }
  ts.forEachChild(n, visit);
};
visit(fn.body);
if (!found) throw new Error('node not found');
const nodeStart = found.getStart(sf);
const nodeEnd = found.getEnd();
const inside = (decl) => decl.getSourceFile() === sf && decl.getStart(sf) >= nodeStart && decl.getEnd() <= nodeEnd;
const inFn = (decl) => decl.getSourceFile() === sf && decl.getStart(sf) >= fn.getStart(sf) && decl.getEnd() <= fn.getEnd();

const props = new Map(); // name -> { type }
const imports = new Map(); // module -> { def, named:Set, ns }
const typeOnlyNames = new Set();
const moduleLocals = new Set();
const importOf = (decl) => {
  let n = decl;
  while (n && !ts.isImportDeclaration(n)) n = n.parent;
  return n;
};
const isTypePosition = (id) => {
  let n = id.parent;
  while (n) {
    if (ts.isTypeNode(n) && !ts.isExpressionWithTypeArguments(n)) return true;
    if (ts.isExpression(n) || ts.isStatement(n)) return false;
    n = n.parent;
  }
  return false;
};
const collect = (n) => {
  if (ts.isIdentifier(n)) {
    const parent = n.parent;
    const isPropName = (ts.isPropertyAccessExpression(parent) && parent.name === n)
      || (ts.isJsxAttribute(parent) && parent.name === n)
      || (ts.isPropertyAssignment(parent) && parent.name === n)
      || (ts.isQualifiedName(parent) && parent.right === n)
      || (ts.isBindingElement(parent) && parent.propertyName === n);
    if (!isPropName) {
      let sym = ts.isShorthandPropertyAssignment(parent)
        ? checker.getShorthandAssignmentValueSymbol(parent)
        : checker.getSymbolAtLocation(n);
      if (sym && sym.flags & ts.SymbolFlags.Alias && !(sym.declarations ?? []).some((d) => importOf(d))) {
        sym = checker.getAliasedSymbol(sym);
      }
      const decl = sym?.declarations?.[0];
      if (decl && decl.getSourceFile() === sf && !inside(decl)) {
        const imp = importOf(decl);
        if (imp) {
          const mod = imp.moduleSpecifier.text;
          if (!imports.has(mod)) imports.set(mod, { def: null, named: new Map(), ns: null, typeAll: Boolean(imp.importClause?.isTypeOnly) });
          const entry = imports.get(mod);
          if (ts.isImportClause(decl)) entry.def = n.text;
          else if (ts.isNamespaceImport(decl)) entry.ns = n.text;
          else if (ts.isImportSpecifier(decl)) {
            const imported = (decl.propertyName ?? decl.name).text;
            const typeOnly = entry.typeAll || decl.isTypeOnly || isTypePosition(n);
            const prev = entry.named.get(n.text);
            entry.named.set(n.text, { imported, typeOnly: prev ? prev.typeOnly && typeOnly : typeOnly });
          }
        } else if (inFn(decl)) {
          if (!props.has(n.text)) {
            const type = checker.getTypeOfSymbol(sym);
            props.set(n.text, { type, node: n });
          }
        } else if (decl.parent === sf || ts.isVariableDeclaration(decl)) {
          moduleLocals.add(n.text);
          if (isTypePosition(n)) typeOnlyNames.add(n.text);
        }
      }
    }
  }
  ts.forEachChild(n, collect);
};
collect(found);

const targetAbs = path.resolve(target);
const targetDir = path.dirname(targetAbs);
const relModule = (absNoExt) => {
  let rel = path.relative(targetDir, absNoExt).replace(/\\/g, '/');
  if (!rel.startsWith('.')) rel = './' + rel;
  return rel;
};
const rebaseImport = (mod) => mod.startsWith('.') ? relModule(path.resolve(path.dirname(mapFile), mod)) : mod;
const fixTypeText = (s) => s.replace(/\(\{[^{}]*\}: \{/g, '(args: {').replace(/import\("([^"]+)"\)/g, (_, p) => {
  const norm = p.replace(/\\/g, '/');
  const nm = norm.lastIndexOf('/node_modules/');
  if (nm >= 0) {
    let pkg = norm.slice(nm + '/node_modules/'.length).replace(/\/index$/, '');
    if (pkg.startsWith('@types/')) pkg = pkg.slice('@types/'.length);
    return `import("${pkg}")`;
  }
  if (!norm.startsWith('.') && !path.isAbsolute(norm)) return `import("${norm}")`;
  return `import("${relModule(path.resolve(path.dirname(mapFile), norm))}")`;
});
const KNOWN_TYPES = {
  routeDraft: { type: 'RouteDraft', from: 'src/screens/MapScreen/hooks/useRouteDraft' },
};
const flags = ts.TypeFormatFlags.NoTruncation | ts.TypeFormatFlags.UseFullyQualifiedType
  | ts.TypeFormatFlags.WriteArrowStyleSignature;
const propLines = [];
const problems = [];
for (const [propName, { type, node }] of [...props].sort(([a], [b]) => a.localeCompare(b))) {
  let typeText;
  if (propName === 'styles') typeText = 'MapStyles';
  else if (KNOWN_TYPES[propName]) typeText = KNOWN_TYPES[propName].type;
  else typeText = fixTypeText(checker.typeToString(type, node, flags));
  if (/__type|typeof |\bany\b/.test(typeText) && propName !== 'styles') problems.push(`${propName}: ${typeText.slice(0, 160)}`);
  if (typeText.length > 400) problems.push(`${propName}: long type (${typeText.length})`);
  propLines.push(`  ${propName}: ${typeText};`);
}
// Module-level constants of MapScreen are copied into the component file.
const copiedLocals = [];
for (const local of moduleLocals) {
  const stmt = sf.statements.find((st) => ts.isVariableStatement(st)
    && st.declarationList.declarations.some((d) => d.name.getText(sf) === local));
  if (stmt) copiedLocals.push(stmt.getFullText(sf).trim());
  else problems.push('module local not copied: ' + local);
}

// Type names printed unqualified (aliases) resolve through MapScreen's own imports.
const allTypeText = propLines.join('\n');
for (const stmt of sf.statements) {
  if (!ts.isImportDeclaration(stmt) || !stmt.importClause) continue;
  const mod = stmt.moduleSpecifier.text;
  const bindingsOf = [];
  const clause = stmt.importClause;
  if (clause.name) bindingsOf.push({ local: clause.name.text, imported: null });
  if (clause.namedBindings && ts.isNamedImports(clause.namedBindings)) {
    for (const el of clause.namedBindings.elements) {
      bindingsOf.push({ local: el.name.text, imported: (el.propertyName ?? el.name).text });
    }
  }
  for (const b of bindingsOf) {
    if (!new RegExp(`(^|[^.\\w"])${b.local}\\b`).test(allTypeText)) continue;
    if (!imports.has(mod)) imports.set(mod, { def: null, named: new Map(), ns: null, typeAll: false });
    const e = imports.get(mod);
    if (b.imported === null) { if (!e.def) e.def = b.local; continue; }
    if (!e.named.has(b.local)) e.named.set(b.local, { imported: b.imported, typeOnly: true });
  }
}
const importLines = [...imports.keys()].sort().map((mod) => {
  const e = imports.get(mod);
  const from = rebaseImport(mod);
  if (e.ns) return `import * as ${e.ns} from '${from}';`;
  const named = [...e.named].map(([local, { imported, typeOnly }]) =>
    `${typeOnly && !e.typeAll ? 'type ' : ''}${imported === local ? local : `${imported} as ${local}`}`);
  const parts = [e.def, named.length ? `{ ${named.join(', ')} }` : null].filter(Boolean).join(', ');
  return `import ${e.typeAll ? 'type ' : ''}${parts} from '${from}';`;
});
for (const [propName, known] of Object.entries(KNOWN_TYPES)) {
  if (props.has(propName)) importLines.push(`import type { ${known.type} } from '${relModule(path.resolve(known.from))}';`);
}
if (props.has('styles')) importLines.push(`import type { MapStyles } from '${relModule(path.resolve('src/screens/MapScreen/styles'))}';`);
if (!imports.has('react')) importLines.unshift("import React from 'react';");

let jsx = text.slice(nodeStart, nodeEnd);
const isExpr = ts.isJsxExpression(found);
const body = isExpr ? `<>${jsx}</>` : jsx;
// Re-indent body to 4 spaces base.
const startCol = sf.getLineAndCharacterOfPosition(nodeStart).character;
const reindent = body.split('\n').map((l, i) => (i === 0 ? l : l.startsWith(' '.repeat(startCol)) ? l.slice(startCol) : l.trimStart()))
  .map((l, i) => (i === 0 ? '    ' + l : '    ' + l)).join('\n');
const propNames = [...props.keys()].sort();
const component = `${importLines.join('\n')}
${copiedLocals.length ? `\n${copiedLocals.join('\n')}\n` : ''}
export interface ${name}Props {
${propLines.join('\n')}
}

export function ${name}({
${propNames.map((p) => `  ${p},`).join('\n')}
}: ${name}Props) {
  return (
${reindent}
  );
}
`;
const indent = ' '.repeat(startCol);
const call = `<${name}\n${propNames.map((p) => `${indent}  ${p}={${p}}`).join('\n')}\n${indent}/>`;
console.log(`props ${propNames.length}: ${propNames.join(', ')}`);
if (problems.length) console.log('PROBLEMS:\n  ' + problems.join('\n  '));
if (dry) process.exit(0);
fs.writeFileSync(targetAbs, component);
const eol = text.includes('\r\n') ? '\r\n' : '\n';
let out = text.slice(0, nodeStart) + call.replace(/\n/g, eol) + text.slice(nodeEnd);
let rel = path.relative(path.dirname(mapFile), targetAbs).replace(/\\/g, '/').replace(/\.tsx?$/, '');
if (!rel.startsWith('.')) rel = './' + rel;
const anchor = "import { useGatheringWorkflow }";
const ai = out.indexOf(anchor);
out = out.slice(0, ai) + `import { ${name} } from '${rel}';${eol}` + out.slice(ai);
fs.writeFileSync(mapFile, out);
console.log('wrote', target, component.split('\n').length, 'lines');
