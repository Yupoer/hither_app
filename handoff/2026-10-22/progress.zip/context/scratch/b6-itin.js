const fs = require('fs');
const rw = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const s = raw.replace(/\r\n/g, '\n');
  const out = fn(s);
  if (out === s) throw new Error('no change ' + p);
  fs.writeFileSync(p, out.replace(/\n/g, eol));
};
const rep = (s, a, b) => { if (!s.includes(a)) throw new Error('missing ' + a.slice(0, 70)); return s.replace(a, b); };
const tripHandler = `  const handleUpdateTripDetails = useCallback(async (days: number, date: string) => {
    if (!groupId) return;
    // Departure picker enforces ≥ today for new choices. Existing past
    // departures can be re-saved unchanged so in-progress trips don't jump.
    // Route sheet: local draft only — flush on dismiss.
    routeDraft.setTripDetails(days, date);
  }, [groupId, routeDraft]);
`;
rw('src/screens/MapScreen.tsx', (s) => {
  s = rep(s, '  const routeFlushInFlightRef = useRef(false);\n', '');
  s = rep(s, '    routeFlushInFlightRef,\n', '');
  s = rep(s, tripHandler, '');
  return rep(s, '    handleUpdateEmojiColor,\n    openKmlImportForScope,\n  } = useItineraryMutations({', '    handleUpdateEmojiColor,\n    handleUpdateTripDetails,\n    openKmlImportForScope,\n  } = useItineraryMutations({');
});
rw('src/screens/MapScreen/hooks/useItineraryMutations.ts', (s) => {
  s = rep(s, '  routeFlushInFlightRef: React.RefObject<boolean>;\n', '');
  s = rep(s, '  routeFlushInFlightRef,\n', '');
  s = rep(s, "import React, { useCallback } from 'react';", "import React, { useCallback, useRef } from 'react';");
  s = rep(s, '}: UseItineraryMutationsInput) {\n', '}: UseItineraryMutationsInput) {\n  const routeFlushInFlightRef = useRef(false);\n');
  s = rep(s, '  return {\n    flushRouteDraft,', `${tripHandler}
  return {\n    flushRouteDraft,`);
  return rep(s, '    handleUpdateEmojiColor,\n    openKmlImportForScope,\n  };', '    handleUpdateEmojiColor,\n    handleUpdateTripDetails,\n    openKmlImportForScope,\n  };');
});
console.log('ok');
