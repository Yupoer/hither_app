-- REVIEW_FIX #158 r4: executable daily-accommodation security + concurrency tests.
-- Trigger DDL runs as test-admin (reset role); authenticated only for JWT RPC calls.
-- pgTAP-oriented. Requires full schema (is_member, memberships, groups, etc.).
-- Single-session tests run inside a transaction (set local role/jwt).
-- Concurrent dblink race runs after COMMIT so peer sessions see fixtures.

create extension if not exists pgtap with schema extensions;


set search_path = extensions, public, auth;
select plan(22);

-- ============================================================
-- Single-session block (transactional auth + fixtures)
-- ============================================================
begin;

select has_function(
  'extensions',
  'set_daily_accommodation_with_auto_add',
  array['uuid','date','text','text','double precision','double precision','uuid','int']
);
select has_function(
  'extensions',
  'clear_daily_accommodation_with_downgrade',
  array['uuid','date','int']
);
select has_function(
  'extensions',
  'set_accommodation_auto_add',
  array['uuid','boolean']
);
select has_function(
  'public',
  'set_daily_accommodation_with_auto_add',
  array['uuid','date','text','text','double precision','double precision','uuid','int']
);
select has_function(
  'public',
  'clear_daily_accommodation_with_downgrade',
  array['uuid','date','int']
);
select has_function(
  'public',
  'set_accommodation_auto_add',
  array['uuid','boolean']
);

-- Fixtures: profiles.nickname (schema requires nickname, not display_name).
insert into auth.users (id, email, is_anonymous) values
  ('d1111111-1111-4111-8111-111111111111', 'daily-leader@example.test', false),
  ('d2222222-2222-4222-8222-222222222222', 'daily-anon-leader@example.test', true),
  ('d3333333-3333-4333-8333-333333333333', 'daily-leader-b@example.test', false);

insert into public.profiles (id, nickname, anonymous_expires_at) values
  ('d1111111-1111-4111-8111-111111111111', 'DailyLeader', null),
  (
    'd2222222-2222-4222-8222-222222222222',
    'DailyAnonLeader',
    now() - interval '1 hour'
  ),
  ('d3333333-3333-4333-8333-333333333333', 'DailyLeaderB', null);

insert into public.groups (id, name, invite_code, created_by, accommodation_auto_add) values
(
  'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
  'Daily stay trip',
  'DAY001',
  'd1111111-1111-4111-8111-111111111111',
  true
),
(
  'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
  'Anon leader daily trip',
  'DAY002',
  'd2222222-2222-4222-8222-222222222222',
  true
),
(
  'dccccccc-cccc-4ccc-8ccc-cccccccccccc',
  'Concurrent race trip',
  'DAY003',
  'd1111111-1111-4111-8111-111111111111',
  true
),
(
  'dddddddd-dddd-4ddd-8ddd-dddddddddddd',
  'Rollback trip',
  'DAY004',
  'd1111111-1111-4111-8111-111111111111',
  true
);

insert into public.memberships (group_id, user_id, role, created_at) values
  (
    'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
    'd1111111-1111-4111-8111-111111111111',
    'leader',
    now() - interval '2 days'
  ),
  (
    'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
    'd2222222-2222-4222-8222-222222222222',
    'leader',
    now() - interval '2 days'
  ),
  (
    'dccccccc-cccc-4ccc-8ccc-cccccccccccc',
    'd1111111-1111-4111-8111-111111111111',
    'leader',
    now() - interval '2 days'
  ),
  (
    'dccccccc-cccc-4ccc-8ccc-cccccccccccc',
    'd3333333-3333-4333-8333-333333333333',
    'leader',
    now() - interval '2 days'
  ),
  (
    'dddddddd-dddd-4ddd-8ddd-dddddddddddd',
    'd1111111-1111-4111-8111-111111111111',
    'leader',
    now() - interval '2 days'
  );

-- Membership setup stamps a fresh anonymous window; move it past expiry
-- through the internal write gate.
select public.allow_anonymous_expiry_write();
update public.profiles
set anonymous_expires_at = now() - interval '1 hour'
where id = 'd2222222-2222-4222-8222-222222222222';

-- Expired anonymous leader: memberships.role=leader but is_member false → denied.
set local role authenticated;
select set_config('request.jwt.claim.sub', 'd2222222-2222-4222-8222-222222222222', true);
select set_config('request.jwt.claim.role', 'authenticated', true);

select ok(
  not extensions.is_member('dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'),
  'expired anonymous leader is_member false despite role=leader'
);

select throws_ok(
  $$select public.set_daily_accommodation_with_auto_add(
    'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'::uuid,
    '2026-08-10'::date,
    'Hotel',
    null,
    25.0,
    121.0,
    null,
    1
  )$$,
  null,
  null,
  'expired anonymous leader cannot set_daily_accommodation_with_auto_add'
);

select throws_ok(
  $$select public.clear_daily_accommodation_with_downgrade(
    'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'::uuid,
    '2026-08-10'::date,
    1
  )$$,
  null,
  null,
  'expired anonymous leader cannot clear_daily_accommodation_with_downgrade'
);

select throws_ok(
  $$select public.set_accommodation_auto_add(
    'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb'::uuid,
    false
  )$$,
  null,
  null,
  'expired anonymous leader cannot set_accommodation_auto_add'
);

-- Direct table write also denied by expiry-aware RLS.
select throws_ok(
  $$insert into public.daily_accommodations (
    group_id, stay_date, title, latitude, longitude
  ) values (
    'dbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
    '2026-08-10',
    'Hotel RLS',
    25.0,
    121.0
  )$$,
  null,
  null,
  'expired anonymous leader denied daily_accommodations insert via RLS'
);

-- Active registered leader: none→some auto-add under serialization.
select set_config('request.jwt.claim.sub', 'd1111111-1111-4111-8111-111111111111', true);

select lives_ok(
  $$select public.set_accommodation_auto_add(
    'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid,
    true
  )$$,
  'active leader can set_accommodation_auto_add'
);

select lives_ok(
  $$select public.set_daily_accommodation_with_auto_add(
    'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid,
    '2026-08-11'::date,
    'Stay A',
    'Addr',
    25.1,
    121.1,
    null,
    1
  )$$,
  'active leader none→some succeeds'
);

select is(
  (select count(*)::int from public.daily_accommodations
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and stay_date = '2026-08-11'),
  1,
  'none→some yields exactly one daily row'
);

select is(
  (select count(*)::int from public.itinerary_items
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and kind = 'accommodation'
      and stay_anchor = true
      and coalesce(day, 1) = 1),
  2,
  'none→some auto-add inserts exactly two stay_anchor cards'
);

-- Second call serializes as some→some: still one daily; no extra auto-add cards.
select lives_ok(
  $$select public.set_daily_accommodation_with_auto_add(
    'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid,
    '2026-08-11'::date,
    'Stay B',
    'Addr2',
    25.2,
    121.2,
    null,
    1
  )$$,
  'active leader some→some succeeds under same lock path'
);

select is(
  (select count(*)::int from public.daily_accommodations
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and stay_date = '2026-08-11'),
  1,
  'serial some→some converges to one daily row'
);

select is(
  (select count(*)::int from public.itinerary_items
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and kind = 'accommodation'
      and coalesce(day, 1) = 1),
  2,
  'second set does not double auto-add (still two accommodation cards)'
);

-- Atomic clear + anchor downgrade.
select lives_ok(
  $$select public.clear_daily_accommodation_with_downgrade(
    'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'::uuid,
    '2026-08-11'::date,
    1
  )$$,
  'active leader clear+downgrade succeeds in one RPC'
);

select is(
  (select count(*)::int from public.daily_accommodations
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and stay_date = '2026-08-11'),
  0,
  'clear removes daily row'
);

select is(
  (select count(*)::int from public.itinerary_items
    where group_id = 'daaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa'
      and kind = 'accommodation'
      and stay_anchor = true
      and coalesce(day, 1) = 1),
  0,
  'clear downgrades stay_anchor (cards may remain, locks released)'
);

-- ============================================================
-- Deterministic second-insert failure → full transaction rollback.
-- Trigger fails only the 2nd stay_anchor accommodation insert so the
-- daily upsert + first card cannot stick after the RPC aborts.
--
-- CRITICAL: authenticated has DML only (no TRIGGER / ownership on
-- itinerary_items). Install and remove the helper under test-admin
-- (reset role), then switch to authenticated only for the RPC call.
-- ============================================================
reset role;

create or replace function public._test_fail_second_stay_anchor()
returns trigger
language plpgsql
as $$
declare
  n int;
begin
  if TG_OP = 'INSERT'
     and NEW.kind = 'accommodation'
     and NEW.stay_anchor = true
     and NEW.group_id = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd'::uuid
  then
    select count(*)::int into n
    from public.itinerary_items i
    where i.group_id = NEW.group_id
      and i.kind = 'accommodation'
      and i.stay_anchor = true
      and coalesce(i.day, 1) = coalesce(NEW.day, 1);
    if n >= 1 then
      raise exception 'test_second_card_fail'
        using errcode = 'P0001';
    end if;
  end if;
  return NEW;
end;
$$;

drop trigger if exists trg_test_fail_second_stay_anchor on public.itinerary_items;
create trigger trg_test_fail_second_stay_anchor
  before insert on public.itinerary_items
  for each row execute function public._test_fail_second_stay_anchor();

-- RPC under authenticated JWT (active leader); trigger runs in same txn.
set local role authenticated;
select set_config('request.jwt.claim.sub', 'd1111111-1111-4111-8111-111111111111', true);
select set_config('request.jwt.claim.role', 'authenticated', true);

select throws_ok(
  $$select public.set_daily_accommodation_with_auto_add(
    'dddddddd-dddd-4ddd-8ddd-dddddddddddd'::uuid,
    '2026-08-12'::date,
    'RollbackStay',
    null,
    25.3,
    121.3,
    null,
    1
  )$$,
  'P0001',
  'test_second_card_fail',
  'second stay_anchor card failure aborts set RPC'
);

-- Counts as admin so RLS cannot mask residual rows if any.
reset role;

select is(
  (select count(*)::int from public.daily_accommodations
    where group_id = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd'
      and stay_date = '2026-08-12'),
  0,
  'failed second card rolls back daily upsert (no partial daily row)'
);

select is(
  (select count(*)::int from public.itinerary_items
    where group_id = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd'
      and kind = 'accommodation'),
  0,
  'failed second card rolls back first card insert (no partial cards)'
);

drop trigger if exists trg_test_fail_second_stay_anchor on public.itinerary_items;
drop function if exists public._test_fail_second_stay_anchor();

-- Commit fixtures + single-session results so dblink peers can see them.
-- (Race group dccccccc has no daily row yet; leaders remain.)
-- Role is already test-admin after reset above; commit ends local role state.
select * from finish();
rollback;
