// Summarize failing source-string assertions from a jest --json report.
// Usage: node b6-failures.js <report.json> [newSourceFile...]
// Prints file:line, the expected substring/pattern, and which new files contain it.
const fs = require('fs');
const [reportPath, ...candidates] = process.argv.slice(2);
const report = JSON.parse(fs.readFileSync(reportPath, 'utf8'));
const sources = candidates.map((p) => [p, fs.readFileSync(p, 'utf8')]);
const strip = (s) => s.replace(/\u001b\[[0-9;]*m/g, '');
for (const suite of report.testResults) {
  for (const t of suite.assertionResults) {
    if (t.status !== 'failed') continue;
    for (const msg of t.failureMessages) {
      const m = strip(msg);
      const sub = m.match(/Expected (substring|pattern): (?:not )?(.*)/);
      const loc = m.match(/__tests__[\\/]([\w.]+):(\d+):\d+/);
      const expected = sub ? sub[2].trim() : '(non-substring failure)';
      let literal = expected;
      if (sub && sub[1] === 'substring') literal = JSON.parse(expected);
      const hits = sources.filter(([, src]) => {
        if (!sub) return false;
        if (sub[1] === 'substring') return src.includes(literal);
        const re = expected.match(/^\/(.*)\/([a-z]*)$/);
        return re ? new RegExp(re[1], re[2]).test(src) : false;
      }).map(([p]) => p.split(/[\\/]/).pop());
      const negated = /Expected (substring|pattern): not/.test(m);
      console.log(`${loc ? loc[1] + ':' + loc[2] : suite.name}\t${negated ? 'NOT ' : ''}${expected.slice(0, 110)}\t=> ${hits.join(',') || '-'}`);
    }
  }
}
