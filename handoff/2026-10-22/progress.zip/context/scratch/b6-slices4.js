const fs = require('fs');
const rw = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const s = raw.replace(/\r\n/g, '\n');
  const out = fn(s);
  if (out === s) throw new Error('no change ' + p);
  fs.writeFileSync(p, out.replace(/\n/g, eol));
};
const rep = (s, a, b) => { if (!s.includes(a)) throw new Error('missing ' + a.slice(0, 80)); return s.replace(a, b); };
rw('src/__tests__/mapUiContracts.test.ts', (s) => {
  s = rep(s, "const membersPane = readFileSync(join(__dirname, '../screens/MapScreen/components/MembersPane.tsx'), 'utf8');",
    "const membersPane = readFileSync(join(__dirname, '../screens/MapScreen/components/MembersPane.tsx'), 'utf8');\nconst routePaneSource = readFileSync(join(__dirname, '../screens/MapScreen/components/RoutePane.tsx'), 'utf8');");
  const a = s.indexOf("    const routePane = mapScreen.indexOf('// ─── 路線');");
  const b = s.indexOf('\n', s.indexOf('const routeBlock = mapScreen.slice(', a));
  if (a < 0 || b < 0) throw new Error('route block');
  s = s.slice(0, a) + `    const routeBlock = routePaneSource + mapScreen.slice(
      mapScreen.indexOf('const renderRouteScope'),
      mapScreen.indexOf('const routePaneBody'),
    );` + s.slice(b);
  s = rep(s, `    const statusBar = mapScreen.indexOf('styles.myStatusBar');
    const refresh = mapScreen.indexOf('RefreshLocationsButton', statusBar);
    const accuracy = mapScreen.indexOf('styles.accuracyRow', refresh);`, `    const statusBar = membersPane.indexOf('styles.myStatusBar');
    const refresh = membersPane.indexOf('RefreshLocationsButton', statusBar);
    const accuracy = membersPane.indexOf('styles.accuracyRow', refresh);`);
  const t0 = s.indexOf('    const toolsStart = mapScreen.indexOf(');
  const t1 = s.indexOf('\n', s.indexOf('const toolsBlock = mapScreen.slice(', t0));
  if (t0 < 0 || t1 < 0) throw new Error('tools block');
  return s.slice(0, t0) + '    const toolsBlock = toolsPane;' + s.slice(t1);
});
rw('src/__tests__/memberStatusSharing.test.ts', (s) => {
  s = rep(s, "const mapStyles = readFileSync(", "const membersPane = readFileSync(join(__dirname, '..', 'screens', 'MapScreen', 'components', 'MembersPane.tsx'), 'utf8');\nconst mapStyles = readFileSync(");
  return rep(s, `    const barStart = mapScreen.indexOf('styles.myStatusBar');
    const barEnd = mapScreen.indexOf('RefreshLocationsButton', barStart);
    const bar = mapScreen.slice(barStart, barEnd);`, `    const barStart = membersPane.indexOf('styles.myStatusBar');
    const barEnd = membersPane.indexOf('RefreshLocationsButton', barStart);
    const bar = membersPane.slice(barStart, barEnd);`);
});
console.log('ok');
