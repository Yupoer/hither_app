const fs=require('fs');
const rw=(p,pairs)=>{const raw=fs.readFileSync(p,'utf8');const eol=raw.includes('\r\n')?'\r\n':'\n';let s=raw.replace(/\r\n/g,'\n');for(const [a,b] of pairs){if(!s.includes(a))throw new Error(p+' missing '+a);s=s.replace(a,b);}fs.writeFileSync(p,s.replace(/\n/g,eol));};
rw('src/__tests__/routeEditorKmlContract.test.ts',[[`    const start = mapScreen.indexOf('const flushRouteDraft = useCallback');
    expect(start).toBeGreaterThanOrEqual(0);
    const block = mapScreen.slice(start, mapScreen.indexOf('const openKmlImport = useCallback', start));`,`    const start = itineraryMutations.indexOf('const flushRouteDraft = useCallback');
    expect(start).toBeGreaterThanOrEqual(0);
    const block = itineraryMutations.slice(start, itineraryMutations.indexOf('const openKmlImport = useCallback', start));`]]);
rw('src/__tests__/buttonInventoryContract.test.ts',[['const corpus = [\n      mapScreen,\n      addPlaceCard,','const corpus = [\n      mapScreen,\n      addPlaceCard,\n      itineraryMutations,']]);
console.log('ok');