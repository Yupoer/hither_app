// Repoint single-line source-string assertions on MapScreen.tsx that now only hold
// in a file extracted from it. Usage (cwd apps/mobile):
//   node b6-repoint.js <srcRelativeNewFile> <newVarName> [--dry]
// For each test that reads screens/MapScreen.tsx into a const, every single-line
// expect(<mapVar>)[.not].toContain('lit') / .toMatch(/re/) that fails against MapScreen.tsx
// but passes against the new file is rewritten to expect(<newVar>), and a const
// reading the new file is declared right after the MapScreen one. Prints each change.
const fs = require('fs');
const path = require('path');
const [newRel, newVar, flag] = process.argv.slice(2);
const dry = flag === '--dry';
const srcRoot = path.join(process.cwd(), 'src');
const mapSrc = fs.readFileSync(path.join(srcRoot, 'screens/MapScreen.tsx'), 'utf8');
const newSrc = fs.readFileSync(path.join(srcRoot, newRel), 'utf8');
const testsDir = path.join(srcRoot, '__tests__');
const evalAssert = (kind, arg, src) => {
  if (kind === 'toContain') {
    // eslint-disable-next-line no-new-func
    const lit = Function(`return (${arg});`)();
    return typeof lit === 'string' ? src.includes(lit) : null;
  }
  // eslint-disable-next-line no-new-func
  const re = Function(`return (${arg});`)();
  return re instanceof RegExp ? re.test(src) : null;
};
for (const name of fs.readdirSync(testsDir)) {
  if (!/\.test\.tsx?$/.test(name)) continue;
  const file = path.join(testsDir, name);
  const raw = fs.readFileSync(file, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const lines = raw.replace(/\r\n/g, '\n').split('\n');
  const declRe = /^(\s*)const (\w+) = .*['"`][^'"`]*screens\/MapScreen\.tsx['"`]/;
  const declIdxs = lines.map((l, idx) => (declRe.test(l) ? idx : -1)).filter((idx) => idx >= 0);
  if (!declIdxs.length) continue;
  let changedTotal = 0;
  // Process declarations bottom-up so inserted lines do not shift pending scopes.
  for (let d = declIdxs.length - 1; d >= 0; d--) {
  const declIdx = declIdxs[d];
  const scopeEnd = d + 1 < declIdxs.length ? declIdxs[d + 1] : lines.length;
  const [, indent, mapVar] = lines[declIdx].match(declRe);
  const re = new RegExp(`^(\\s*expect\\()${mapVar}(\\)(\\.not)?\\.(toContain|toMatch)\\((.*)\\);\\s*)$`);
  let changed = 0;
  for (let i = declIdx + 1; i < scopeEnd; i++) {
    const m = lines[i].match(re);
    if (!m) continue;
    const negated = Boolean(m[3]);
    const kind = m[4];
    let onMap;
    let onNew;
    try {
      onMap = evalAssert(kind, m[5], mapSrc);
      onNew = evalAssert(kind, m[5], newSrc);
    } catch {
      continue;
    }
    if (onMap === null || onNew === null) continue;
    const passMap = negated ? !onMap : onMap;
    const passNew = negated ? !onNew : onNew;
    if (!passMap && passNew && !negated) {
      lines[i] = `${m[1]}${newVar}${m[2]}`;
      changed++;
      console.log(`${name}:${i + 1}  -> ${newVar}`);
    }
  }
  if (!changed) continue;
  changedTotal += changed;
  const scopeHasDecl = lines.slice(indent ? declIdx : 0, indent ? scopeEnd : lines.length)
    .some((l) => new RegExp(`^${indent}const ${newVar} = `).test(l));
  if (!scopeHasDecl) {
    const decl = lines[declIdx].replace(/const \w+/, `const ${newVar}`).replace('screens/MapScreen.tsx', newRel);
    lines.splice(declIdx + 1, 0, decl);
  }
  }
  if (changedTotal && !dry) fs.writeFileSync(file, lines.join('\n').replace(/\n/g, eol));
}
