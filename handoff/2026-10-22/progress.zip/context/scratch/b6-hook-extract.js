// Extract a contiguous run of MapScreen component statements into a custom hook.
// Usage (cwd apps/mobile): node b6-hook-extract.js <startLine> <endLine> <useName> <targetFile> [--dry]
// Statements fully inside [startLine, endLine] move verbatim. Values they read from the
// component scope become typed inputs; names they declare that the rest of MapScreen
// reads become the hook's return value, destructured at the original position.
const path = require('path');
const fs = require('fs');
const ts = require(require.resolve('typescript', { paths: [process.cwd()] }));
const [startLine, endLine, hookName, target, flag] = process.argv.slice(2);
const dry = flag === '--dry';
const mapFile = path.resolve('src/screens/MapScreen.tsx');
const cfg = ts.readConfigFile(path.resolve('tsconfig.json'), ts.sys.readFile);
const parsed = ts.parseJsonConfigFileContent(cfg.config, ts.sys, process.cwd());
const program = ts.createProgram({ rootNames: [mapFile], options: parsed.options });
const checker = program.getTypeChecker();
const sf = program.getSourceFile(mapFile);
const text = sf.getFullText();
const lineOf = (pos) => sf.getLineAndCharacterOfPosition(pos).line + 1;
let fn;
sf.forEachChild((n) => { if (ts.isFunctionDeclaration(n) && n.name?.text === 'MapScreen') fn = n; });
const stmts = fn.body.statements.filter((s) => lineOf(s.getStart(sf)) >= Number(startLine) && lineOf(s.getEnd()) <= Number(endLine));
if (!stmts.length) throw new Error('no statements in range');
const first = stmts[0];
const last = stmts[stmts.length - 1];
const idx0 = fn.body.statements.indexOf(first);
const idx1 = fn.body.statements.indexOf(last);
if (idx1 - idx0 + 1 !== stmts.length) throw new Error('range not contiguous');
const rangeStart = first.getFullStart();
const rangeEnd = last.getEnd();
const inRange = (node) => node.getSourceFile() === sf && node.getStart(sf) >= rangeStart && node.getEnd() <= rangeEnd;
const inFn = (node) => node.getSourceFile() === sf && node.getStart(sf) >= fn.getStart(sf) && node.getEnd() <= fn.getEnd();

// Names declared at the top level of the range.
const declared = new Map(); // name -> symbol
const collectBinding = (nameNode) => {
  if (ts.isIdentifier(nameNode)) declared.set(nameNode.text, checker.getSymbolAtLocation(nameNode));
  else for (const el of nameNode.elements) if (!ts.isOmittedExpression(el)) collectBinding(el.name);
};
for (const st of stmts) {
  if (ts.isVariableStatement(st)) for (const d of st.declarationList.declarations) collectBinding(d.name);
  else if (ts.isFunctionDeclaration(st) && st.name) declared.set(st.name.text, checker.getSymbolAtLocation(st.name));
}

const importOf = (decl) => { let n = decl; while (n && !ts.isImportDeclaration(n)) n = n.parent; return n; };
const isTypePosition = (id) => {
  let n = id.parent;
  while (n) {
    if (ts.isTypeNode(n) && !ts.isExpressionWithTypeArguments(n)) return true;
    if (ts.isExpression(n) || ts.isStatement(n)) return false;
    n = n.parent;
  }
  return false;
};
const isNameOnly = (n) => {
  const p = n.parent;
  return (ts.isPropertyAccessExpression(p) && p.name === n) || (ts.isJsxAttribute(p) && p.name === n)
    || (ts.isPropertyAssignment(p) && p.name === n) || (ts.isQualifiedName(p) && p.right === n)
    || (ts.isBindingElement(p) && p.propertyName === n) || (ts.isPropertySignature(p) && p.name === n)
    || (ts.isMethodDeclaration(p) && p.name === n);
};
const symbolOf = (n) => {
  let sym = ts.isShorthandPropertyAssignment(n.parent) && n.parent.name === n
    ? checker.getShorthandAssignmentValueSymbol(n.parent) : checker.getSymbolAtLocation(n);
  if (sym && sym.flags & ts.SymbolFlags.Alias && !(sym.declarations ?? []).some((d) => importOf(d))) sym = checker.getAliasedSymbol(sym);
  return sym;
};

const inputs = new Map();
const imports = new Map();
const moduleLocals = new Set();
const problems = [];
const visitRange = (n) => {
  if (ts.isIdentifier(n) && !isNameOnly(n)) {
    const sym = symbolOf(n);
    const decl = sym?.declarations?.[0];
    if (decl && decl.getSourceFile() === sf && !inRange(decl)) {
      const imp = importOf(decl);
      if (imp) {
        const mod = imp.moduleSpecifier.text;
        if (!imports.has(mod)) imports.set(mod, { def: null, named: new Map(), ns: null, typeAll: Boolean(imp.importClause?.isTypeOnly) });
        const e = imports.get(mod);
        if (ts.isImportClause(decl)) e.def = n.text;
        else if (ts.isNamespaceImport(decl)) e.ns = n.text;
        else if (ts.isImportSpecifier(decl)) {
          const imported = (decl.propertyName ?? decl.name).text;
          const typeOnly = e.typeAll || decl.isTypeOnly || isTypePosition(n);
          const prev = e.named.get(n.text);
          e.named.set(n.text, { imported, typeOnly: prev ? prev.typeOnly && typeOnly : typeOnly });
        }
      } else if (inFn(decl)) {
        if (!inputs.has(n.text)) {
          if (decl.getStart(sf) > rangeStart) problems.push(`input declared after range: ${n.text} (line ${lineOf(decl.getStart(sf))})`);
          inputs.set(n.text, { sym, node: n });
        }
        // Writes to outer bindings cannot move into a hook.
        const p = n.parent;
        if (ts.isBinaryExpression(p) && p.left === n && p.operatorToken.kind >= ts.SyntaxKind.FirstAssignment
          && p.operatorToken.kind <= ts.SyntaxKind.LastAssignment) problems.push(`assigns outer binding ${n.text}`);
      } else if (decl.parent === sf || ts.isVariableDeclaration(decl) || ts.isTypeAliasDeclaration(decl)) {
        moduleLocals.add(n.text);
      }
    }
  }
  ts.forEachChild(n, visitRange);
};
for (const st of stmts) visitRange(st);

// Outputs: declared names read anywhere in the component outside the range.
const outputs = new Set();
const visitRest = (n) => {
  if (inRange(n)) return;
  if (ts.isIdentifier(n) && !isNameOnly(n) && declared.has(n.text)) {
    const sym = symbolOf(n);
    if (sym && sym === declared.get(n.text)) outputs.add(n.text);
  }
  ts.forEachChild(n, visitRest);
};
visitRest(fn.body);

const targetDir = path.dirname(path.resolve(target));
const relModule = (abs) => { let r = path.relative(targetDir, abs).replace(/\\/g, '/'); if (!r.startsWith('.')) r = './' + r; return r; };
const rebaseImport = (mod) => (mod.startsWith('.') ? relModule(path.resolve(path.dirname(mapFile), mod)) : mod);
const fixTypeText = (s) => s.replace(/\(\{[^{}]*\}: \{/g, '(args: {').replace(/import\("([^"]+)"\)/g, (_, p) => {
  const norm = p.replace(/\\/g, '/');
  const nm = norm.lastIndexOf('/node_modules/');
  if (nm >= 0) {
    let pkg = norm.slice(nm + '/node_modules/'.length).replace(/\/index$/, '');
    if (pkg.startsWith('@types/')) pkg = pkg.slice('@types/'.length);
    return `import("${pkg}")`;
  }
  if (!norm.startsWith('.') && !path.isAbsolute(norm)) return `import("${norm}")`;
  return `import("${relModule(path.resolve(path.dirname(mapFile), norm))}")`;
});
const KNOWN_TYPES = { routeDraft: { type: 'RouteDraft', from: 'src/screens/MapScreen/hooks/useRouteDraft' }, styles: { type: 'MapStyles', from: 'src/screens/MapScreen/styles' } };
const flags = ts.TypeFormatFlags.NoTruncation | ts.TypeFormatFlags.UseFullyQualifiedType | ts.TypeFormatFlags.WriteArrowStyleSignature;
const inputLines = [];
for (const [name, { sym }] of [...inputs].sort(([a], [b]) => a.localeCompare(b))) {
  const typeText = KNOWN_TYPES[name] ? KNOWN_TYPES[name].type : fixTypeText(checker.typeToString(checker.getTypeOfSymbol(sym), fn, flags));
  if (typeText.length > 400) problems.push(`${name}: long type (${typeText.length})`);
  if (/\bany\b/.test(typeText)) problems.push(`${name}: any`);
  inputLines.push(`  ${name}: ${typeText};`);
}
const copied = [];
for (const local of moduleLocals) {
  const st = sf.statements.find((s) => (ts.isVariableStatement(s) && s.declarationList.declarations.some((d) => d.name.getText(sf) === local))
    || (ts.isTypeAliasDeclaration(s) && s.name.text === local));
  if (st) copied.push(st.getFullText(sf).trim());
  else problems.push('module local not copied: ' + local);
}
// Type names printed unqualified resolve through MapScreen imports.
const allTypeText = inputLines.join('\n');
for (const st of sf.statements) {
  if (!ts.isImportDeclaration(st) || !st.importClause) continue;
  const mod = st.moduleSpecifier.text;
  const clause = st.importClause;
  const bs = [];
  if (clause.name) bs.push({ local: clause.name.text, imported: null });
  if (clause.namedBindings && ts.isNamedImports(clause.namedBindings)) for (const el of clause.namedBindings.elements) bs.push({ local: el.name.text, imported: (el.propertyName ?? el.name).text });
  for (const b of bs) {
    if (!new RegExp(`(^|[^.\\w"])${b.local}\\b`).test(allTypeText)) continue;
    if (!imports.has(mod)) imports.set(mod, { def: null, named: new Map(), ns: null, typeAll: false });
    const e = imports.get(mod);
    if (b.imported === null) { if (!e.def) e.def = b.local; continue; }
    if (!e.named.has(b.local)) e.named.set(b.local, { imported: b.imported, typeOnly: true });
  }
}
const importLines = [...imports.keys()].sort().map((mod) => {
  const e = imports.get(mod);
  const from = rebaseImport(mod);
  if (e.ns) return `import * as ${e.ns} from '${from}';`;
  const named = [...e.named].map(([local, { imported, typeOnly }]) => `${typeOnly && !e.typeAll ? 'type ' : ''}${imported === local ? local : `${imported} as ${local}`}`);
  return `import ${e.typeAll ? 'type ' : ''}${[e.def, named.length ? `{ ${named.join(', ')} }` : null].filter(Boolean).join(', ')} from '${from}';`;
});
for (const [name, known] of Object.entries(KNOWN_TYPES)) if (inputs.has(name)) importLines.push(`import type { ${known.type} } from '${relModule(path.resolve(known.from))}';`);

const body = text.slice(rangeStart, rangeEnd).replace(/^\r?\n/, '');
const inputNames = [...inputs.keys()].sort();
const outputNames = [...outputs].sort();
const typeName = hookName.replace(/^use/, 'Use') + 'Input';
const hookSrc = `${importLines.join('\n')}
${copied.length ? `\n${copied.join('\n')}\n` : ''}
export interface ${typeName} {
${inputLines.join('\n')}
}

export function ${hookName}({
${inputNames.map((n) => `  ${n},`).join('\n')}
}: ${typeName}) {
${body.replace(/\r\n/g, '\n')}
  return {
${outputNames.map((n) => `    ${n},`).join('\n')}
  };
}
`;
console.log(`statements ${stmts.length}, inputs ${inputNames.length}: ${inputNames.join(', ')}`);
console.log(`outputs ${outputNames.length}: ${outputNames.join(', ')}`);
if (problems.length) console.log('PROBLEMS:\n  ' + problems.join('\n  '));
if (dry || problems.some((p) => p.startsWith('input declared after') || p.startsWith('assigns outer'))) process.exit(dry ? 0 : 3);
fs.writeFileSync(path.resolve(target), hookSrc);
const eol = text.includes('\r\n') ? '\r\n' : '\n';
const call = `${eol}  const {${eol}${outputNames.map((n) => `    ${n},`).join(eol)}${eol}  } = ${hookName}({${eol}${inputNames.map((n) => `    ${n},`).join(eol)}${eol}  });`;
const callText = outputNames.length ? call : `${eol}  ${hookName}({${eol}${inputNames.map((n) => `    ${n},`).join(eol)}${eol}  });`;
let out = text.slice(0, rangeStart) + callText + text.slice(rangeEnd);
let rel = path.relative(path.dirname(mapFile), path.resolve(target)).replace(/\\/g, '/').replace(/\.tsx?$/, '');
if (!rel.startsWith('.')) rel = './' + rel;
const anchor = 'import { useGatheringWorkflow }';
const ai = out.indexOf(anchor);
out = out.slice(0, ai) + `import { ${hookName} } from '${rel}';${eol}` + out.slice(ai);
fs.writeFileSync(mapFile, out);
console.log('wrote', target);
