const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const rep = (a, b) => { const i = s.indexOf(a); if (i < 0) throw new Error('missing: ' + a.slice(0, 80)); if (s.indexOf(a, i + 1) >= 0) throw new Error('dup: ' + a.slice(0, 80)); s = s.slice(0, i) + b + s.slice(i + a.length); };
rep(`    const dirty = routeDraftDirtyRef.current;
    if (dirty.destinations || dirty.daily || dirty.trip || dirty.deletedIds.length > 0) return;
    await refreshKmlQuota();`, `    if (routeDraft.hasUnsavedChanges()) return;
    await refreshKmlQuota();`);
rep(`  }, [flushRouteDraft, refreshKmlQuota]);`, `  }, [flushRouteDraft, refreshKmlQuota, routeDraft]);`);
rep(`        const next = (routeDraft.latestDestinations() ?? routeEditorServerDestinations).filter(d => d.id !== id);
        optimisticDestinationsRef.current = next;
        setOptimisticDestinations(next);
        routeDraftDirtyRef.current.deletedIds = routeDraftDirtyRef.current.deletedIds.filter(value => value !== id);`,
`        const draft = routeDraft.latestDestinations();
        if (draft) routeDraft.setDestinations(draft.filter(d => d.id !== id));
        routeDraft.forgetDeleted(id);`);
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok');
