const fs = require('fs');
const edit = (p, pairs) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  let s = raw.replace(/\r\n/g, '\n');
  for (const [a, b] of pairs) {
    if (a instanceof RegExp) {
      if (!a.test(s)) throw new Error(p + ' missing ' + a);
      s = s.replace(a, b);
      continue;
    }
    const i = s.indexOf(a);
    if (i < 0) throw new Error(p + ' missing ' + a.slice(0, 60));
    if (s.indexOf(a, i + 1) >= 0) throw new Error('dup ' + a.slice(0, 60));
    s = s.slice(0, i) + b + s.slice(i + a.length);
  }
  fs.writeFileSync(p, s.replace(/\n/g, eol));
};
const m = 'src/screens/MapScreen.tsx';
edit(m, [
  ['    upgradeToEmailAccount,\n', ''],
  ['    journeyStatus,\n    journeyGoing,\n', ''],
  [`  const openCoordinateSheet = useCallback((coords?: { latitude: number; longitude: number }) => {
    setCoordSheetInitial(coords);
    setCoordSheetVisible(true);
  }, []);

`, ''],
  [/  const closeOverlay = useCallback\(\(\) => \{\n[^\n]*\n    setOverlay\(null\);\n  \}, \[\]\);\n/, ''],
  ['              const leaderActionDisabled = false;\n', ''],
]);
edit('src/__tests__/buttonInventoryContract.test.ts', [["    expect(mapScreen).toContain('const closeOverlay = useCallback(() => {');\n", '']]);
edit('src/__tests__/gatheringWorkflowContract.test.ts', [["    expect(mapScreen).toContain('isNetworkRequestError');\n", '']]);
edit('src/__tests__/routeEditorKmlContract.test.ts', [["mapScreen.indexOf('const openCoordinateSheet', start)", "mapScreen.indexOf('const handleLongPressCoordinate', start)"]]);
console.log('ok');
