const fs = require('fs');
const edit = (p, fn) => { const s = fs.readFileSync(p, 'utf8'); const eol = s.includes('\r\n') ? '\r\n' : '\n'; const n = fn(s.replace(/\r\n/g, '\n')).replace(/\n/g, eol); if (n === s) throw new Error('no change ' + p); fs.writeFileSync(p, n); };
edit('src/screens/MapScreen/hooks/useJourneyNavigation.ts', s => s
  .replace("  reorderForNavigation?: (\n    updates: { id: string; position: number; day: number | null }[],\n  ) => Promise<boolean>;\n", '')
  .replace('  reorderForNavigation,\n', ''));
edit('src/__tests__/journeyNavigation.test.tsx', s => {
  s = s.replace("    const reorderForNavigation = jest.fn().mockResolvedValue(true);\n", '')
    .replace("        createRequestId: () => 'request-2',\n        reorderForNavigation,\n", "        createRequestId: () => 'request-2',\n")
    .replace("    expect(reorderForNavigation).not.toHaveBeenCalled();\n    expect(startSession).not.toHaveBeenCalled();\n", "    expect(startSession).not.toHaveBeenCalled();\n");
  const start = s.indexOf("  it('does not let the obsolete remote reorder gate block a durable local Start'");
  const end = s.indexOf('\n  });\n', start) + '\n  });\n'.length;
  if (start < 0) throw new Error('test not found');
  return s.slice(0, start) + s.slice(end).replace(/^\n/, '');
});
console.log('ok');
