const fs = require('fs');
const path = 'src/screens/MapScreen.tsx';
const lines = fs.readFileSync(path, 'utf8').replace(/\r\n/g, '\n').split('\n');
const find = (pred, from = 0) => { const i = lines.findIndex((l, idx) => idx >= from && pred(l)); if (i < 0) throw new Error('nf'); return i; };
const designDoc = find((l) => l.startsWith(' * Design sizes')) - 1;
const helperDoc = designDoc + 8; // "/**" of applyAppTextScale doc
if (lines[helperDoc] !== '/**') throw new Error('helper doc ' + lines[helperDoc]);
const emoji = find((l) => l.startsWith('const EMOJI_STYLE_KEYS'));
const helpers = lines.slice(helperDoc, emoji).join('\n')
  .replace(/^function apply/gm, 'export function apply');
const designComment = lines.slice(designDoc, helperDoc).join('\n');
const rest = lines.slice(emoji).join('\n').replace(/^const makeStyles = \(/m, `${designComment}\nexport const makeStyles = (`);
fs.writeFileSync('src/utils/styleScaling.ts',
  `/* eslint-disable @typescript-eslint/no-explicit-any */\n${helpers.trimEnd()}\n`);
fs.writeFileSync('src/screens/MapScreen/styles.ts', `${rest.trimEnd()}\n`);
const kept = lines.slice(0, designDoc);
while (kept[kept.length - 1] === '') kept.pop();
fs.writeFileSync(path, (kept.join('\n') + '\n').replace(/\n/g, '\r\n'));
console.log('helpers', helpers.split('\n').length, 'styles', rest.split('\n').length, 'map', kept.length);
