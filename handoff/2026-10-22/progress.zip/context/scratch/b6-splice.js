// Usage: node b6-splice.js <file> <startMarker> <endMarker> <replacementFile> [--include-end]
// Replaces text from the first occurrence of startMarker up to (excluding, or including with
// --include-end) the first occurrence of endMarker after it. Markers are JSON-escaped strings.
const fs = require('fs');
const [file, startRaw, endRaw, replacementFile, flag] = process.argv.slice(2);
const src = fs.readFileSync(file, 'utf8');
const eol = src.includes('\r\n') ? '\r\n' : '\n';
const unescape = (s) => s.replace(/\\n/g, eol);
const start = unescape(startRaw);
const end = unescape(endRaw);
const i = src.indexOf(start);
if (i < 0) throw new Error('start marker not found');
if (src.indexOf(start, i + 1) >= 0) throw new Error('start marker not unique');
const j = src.indexOf(end, i + start.length);
if (j < 0) throw new Error('end marker not found');
const stop = flag === '--include-end' ? j + end.length : j;
const replacement = replacementFile === '-' ? ''
  : fs.readFileSync(replacementFile, 'utf8').replace(/\r\n/g, '\n').replace(/\n/g, eol);
fs.writeFileSync(file, src.slice(0, i) + replacement + src.slice(stop));
console.log(`replaced ${src.slice(i, stop).split('\n').length - 1} lines with ${replacement.split('\n').length - 1}`);
