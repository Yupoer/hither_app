﻿const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const rep = (a, b) => { const i = s.indexOf(a); if (i < 0) throw new Error('missing: ' + a.slice(0, 80)); if (s.indexOf(a, i + 1) >= 0) throw new Error('dup: ' + a.slice(0, 80)); s = s.slice(0, i) + b + s.slice(i + a.length); };
rep(`                const dirty = routeDraftDirtyRef.current;
                const hasDirtyDraft = dirty.destinations || dirty.daily || dirty.trip || dirty.deletedIds.length > 0;
                if (hasDirtyDraft && routeDraft.editorScopeIdRef.current !== scopeId) return;
                setRouteEditorScopeId(scopeId);
                if (!hasDirtyDraft) setOptimisticDestinations(scopeDestinations);`,
`                const hasDirtyDraft = routeDraft.hasUnsavedChanges();
                if (hasDirtyDraft && routeDraft.editorScopeIdRef.current !== scopeId) return;
                routeDraft.setEditorScopeId(scopeId);
                if (!hasDirtyDraft) routeDraft.setDestinations(scopeDestinations);`);
rep(`                    setDraftDailyAccommodations((prev) => {
                      const base = prev ?? serverDailyAccommodations;
                      return base.filter((d) => d.stayDate !== stayDate);
                    });
                    routeDraftDirtyRef.current.daily = true;`,
`                    routeDraft.editDaily((base) => base.filter((d) => d.stayDate !== stayDate));`);
rep(`                    setDraftDailyAccommodations((prev) => {
                      const base = prev ?? serverDailyAccommodations;
                      return [
                        ...base.filter((d) => d.stayDate !== stayDate),
                        next,
                      ];
                    });
                    // Setting stay from a gathering point discards that stop;
                    // only the daily accommodation setting remains.
                    setOptimisticDestinations(baseDests.filter((d) => d.id !== destinationId));
                    if (!destinationId.startsWith('draft-')) {
                      routeDraftDirtyRef.current.deletedIds = [
                        ...routeDraftDirtyRef.current.deletedIds.filter((x) => x !== destinationId),
                        destinationId,
                      ];
                    }
                    routeDraftDirtyRef.current.daily = true;
                    routeDraftDirtyRef.current.destinations = true;`,
`                    routeDraft.editDaily((base) => [...base.filter((d) => d.stayDate !== stayDate), next]);
                    // Setting stay from a gathering point discards that stop;
                    // only the daily accommodation setting remains.
                    routeDraft.setDestinations(baseDests.filter((d) => d.id !== destinationId), { dirty: true });
                    if (!destinationId.startsWith('draft-')) routeDraft.markDeleted(destinationId);`);
rep(`                    const base = routeDraft.latestDestinations() ?? routeEditorServerDestinations;
                    const sameDay = base.filter((d) => d.day === day);
                    const insertOrder =
                      sameDay.length > 0
                        ? Math.max(...sameDay.map((d) => d.order)) + 1
                        : (fallbackStop?.order ?? 0) + 1;
                    const tempId = \`draft-acc-\${Date.now()}-\${destinationMutationSequenceRef.current++}\`;
                    const draftCard: Destination = {
                      id: tempId,`,
`                    const base = routeDraft.latestDestinations() ?? routeEditorServerDestinations;
                    const insertOrder = nextOrderInDay(base, day, (fallbackStop?.order ?? 0) + 1);
                    const draftCard: Destination = {
                      id: routeDraft.nextDraftId('draft-acc'),`);
rep(`                    const shifted = base.map((d) => {
                      if (d.day !== day) return d;
                      if (d.order >= insertOrder) return { ...d, order: d.order + 1 };
                      return d;
                    });
                    setOptimisticDestinations(
                      [...shifted, draftCard].sort((a, b) => {
                        if ((a.day ?? 0) !== (b.day ?? 0)) {
                          return (a.day ?? 0) - (b.day ?? 0);
                        }
                        return a.order - b.order;
                      }),
                    );
                    routeDraftDirtyRef.current.destinations = true;`,
`                    routeDraft.setDestinations(insertDraftDestination(base, draftCard), { dirty: true });`);
rep(`                    const base = routeDraft.latestDestinations() ?? routeEditorServerDestinations;
                    const sameDay = base.filter((d) => d.day === day);
                    const insertOrder =
                      sameDay.length > 0
                        ? Math.max(...sameDay.map((d) => d.order)) + 1
                        : 0;
                    const tempId = \`draft-fav-\${Date.now()}-\${destinationMutationSequenceRef.current++}\`;
                    const draftStop: Destination = {
                      id: tempId,`,
`                    const base = routeDraft.latestDestinations() ?? routeEditorServerDestinations;
                    const insertOrder = nextOrderInDay(base, day, 0);
                    const draftStop: Destination = {
                      id: routeDraft.nextDraftId('draft-fav'),`);
rep(`                    const shifted = base.map((d) => {
                      if (d.day !== day) return d;
                      if (d.order >= insertOrder) return { ...d, order: d.order + 1 };
                      return d;
                    });
                    setOptimisticDestinations(
                      [...shifted, draftStop].sort((a, b) => {
                        if ((a.day ?? 0) !== (b.day ?? 0)) {
                          return (a.day ?? 0) - (b.day ?? 0);
                        }
                        return a.order - b.order;
                      }),
                    );
                    routeDraftDirtyRef.current.destinations = true;`,
`                    routeDraft.setDestinations(insertDraftDestination(base, draftStop), { dirty: true });`);
s = s.replace('    groupId, optimisticTripDays, optimisticDepartureDate, group, dailyAccommodations,', '    groupId, routeTripDays, routeDepartureDate, group, dailyAccommodations,');
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok');
