// Remove import bindings ESLint reports as unused, in the given files (cwd apps/mobile).
const { execFileSync } = require('child_process');
const path = require('path');
const files = process.argv.slice(2);
let out;
try {
  out = execFileSync('npx', ['eslint', '-f', 'json', ...files], { encoding: 'utf8', shell: true, maxBuffer: 64 << 20 });
} catch (e) {
  out = e.stdout;
}
const results = JSON.parse(out);
for (const r of results) {
  const src = require('fs').readFileSync(r.filePath, 'utf8').split(/\r?\n/);
  const names = r.messages
    .filter((m) => m.ruleId === '@typescript-eslint/no-unused-vars' && /^import\b|^\s+\w+,?$|^\s*(type )?\w+( as \w+)?,?\s*$/.test(src[m.line - 1] ?? '')
      && /is defined but never used/.test(m.message))
    .map((m) => m.message.match(/'([^']+)'/)[1]);
  if (!names.length) continue;
  execFileSync('node', [path.join(__dirname, 'b6-unused-imports.js'), r.filePath, ...names], { stdio: 'inherit' });
}
