﻿const fs = require('fs');
const drop = (p, lines) => { const raw = fs.readFileSync(p, 'utf8'); const eol = raw.includes('\r\n') ? '\r\n' : '\n'; let s = raw.replace(/\r\n/g, '\n'); for (const l of lines) { const t = l + '\n'; if (!s.includes(t)) throw new Error(p + ' missing ' + l); s = s.replace(t, ''); } fs.writeFileSync(p, s.replace(/\n/g, eol)); };
drop('src/__tests__/dynamicTypeContract.test.ts', ["    expect(mapScreen).toContain('optimisticDepartureDate ?? group?.departureDate');"]);
drop('src/__tests__/mapUiContracts.test.ts', [
  "    expect(mapScreen).toContain('setOptimisticDestinations(null);');",
  "    expect(mapScreen).toContain('meetAt: alignedMeetAt.toISOString()');",
  "    // Trip date edits are route-draft local; flush writes trip + reorder together.",
  "    expect(mapScreen).toContain('routeDraftDirtyRef.current.trip = true');",
]);
drop('src/__tests__/routeEditorKmlContract.test.ts', [
  "    // Navigation promote still persists immediately.",
  "    expect(mapScreen).toContain('reorderForNavigationRef.current = persistReorderNow');",
  "    expect(block).toContain('deletedIds: [...routeDraftDirtyRef.current.deletedIds]');",
  "    expect(mapScreen).toContain('if (!optimisticDestinations || routeDraftDirtyRef.current.destinations) return');",
  "    expect(mapScreen).toContain('if (hasDirtyDraft && routeEditorScopeIdRef.current !== scopeId) return');",
  "    expect(mapScreen).toContain('if (!hasDirtyDraft) setOptimisticDestinations(scopeDestinations)');",
]);
console.log('ok');
