const fs = require('fs');
const rw = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const s = raw.replace(/\r\n/g, '\n');
  const out = fn(s);
  if (out === s) throw new Error('no change ' + p);
  fs.writeFileSync(p, out.replace(/\n/g, eol));
};
const removeIt = (s, title) => {
  const i = s.indexOf(`  it('${title}'`);
  if (i < 0) throw new Error('it missing ' + title);
  const j = s.indexOf('\n  });\n', i) + '\n  });\n'.length;
  return s.slice(0, i) + s.slice(j).replace(/^\n/, '');
};
rw('src/__tests__/performanceRegression.test.ts', (s) => {
  s = removeIt(s, 'does not put translator identity in gathering-workflow effect deps');
  return s.replace(`    expect(mapScreen).toContain(
      'gathering-workflow:\${groupId}:\${++workflowChannelSeqRef.current}',
    );
    expect(mapScreen).not.toContain('gathering-workflow:\${groupId}\`');
`, '');
});
rw('src/__tests__/gatheringWorkflowContract.test.ts', (s) => {
  s = removeIt(s, "filters the request inbox to the leader\\'s active route scope");
  s = s.replace("    expect(mapScreen).toContain('scheduleWorkflowReload');\n", '');
  return s.replace("mapScreen.indexOf('const tRef', syncStart)",
    "mapScreen.indexOf('useForegroundReconcile(Boolean(groupId), recoverPendingLocationRefreshes)', syncStart)");
});
console.log('ok');
