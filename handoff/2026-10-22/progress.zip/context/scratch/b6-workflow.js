const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const startMarker = '  // Keep translator out of effect deps';
const endMarker = '  }, [groupId, loadGatheringWorkflow, scheduleWorkflowReload]);\n';
const i = s.indexOf(startMarker);
const j = s.indexOf(endMarker, i) + endMarker.length;
if (i < 0 || j < endMarker.length) throw new Error('markers');
let block = s.slice(i, j);
const drop = (text) => { if (!block.includes(text)) throw new Error('missing in block: ' + text.slice(0, 50)); block = block.replace(text, ''); };
drop('  const workflowGroupRef = useRef(groupId);\n  workflowGroupRef.current = groupId;\n');
drop(`  const mapMountedRef = useRef(true);
  useEffect(() => {
    mapMountedRef.current = true;
    return () => { mapMountedRef.current = false; };
  }, []);
`);
drop('  useForegroundReconcile(Boolean(groupId), recoverPendingLocationRefreshes);\n');
drop('  const WORKFLOW_MIN_INTERVAL_MS = 2_500;\n');
block = block.split('mapMountedRef').join('mountedRef')
  .replace('  const tRef = useRef(t);', '  const workflowReloadRef = useRef<ReturnType<typeof setTimeout> | null>(null);\n  const mountedRef = useRef(true);\n  useEffect(() => {\n    mountedRef.current = true;\n    return () => { mountedRef.current = false; };\n  }, []);\n  const tRef = useRef(t);')
  .replace('const isMainLeaderRef = useRef(isLeader);\n  isMainLeaderRef.current = isLeader;', 'const isMainLeaderRef = useRef(isMainLeader);\n  isMainLeaderRef.current = isMainLeader;')
  .replace('const isSubgroupLeaderRef = useRef(isMySubgroupLeader);\n  isSubgroupLeaderRef.current = isMySubgroupLeader;', 'const isSubgroupLeaderRef = useRef(isSubgroupLeader);\n  isSubgroupLeaderRef.current = isSubgroupLeader;')
  .replace('const userIdRef = useRef(user?.id);\n  userIdRef.current = user?.id;', 'const userIdRef = useRef(userId);\n  userIdRef.current = userId;')
  .split('user?.id').join('userId');
const hook = `import { useCallback, useEffect, useRef, useState } from 'react';
import { Alert } from 'react-native';
import { fetchDestinationArrivals, fetchPendingGatherPointRequests } from '../../../api/client';
import { isDemoGroup } from '../../../api/demo';
import { supabase } from '../../../api/supabase';
import type { TranslationKey } from '../../../i18n';
import { getCoreOperationOutbox } from '../../../state/coreDataSync';
import { useForegroundReconcile } from '../../../state/useForegroundReconcile';
import type { Destination, DestinationArrival, GatherPointRequest } from '../../../types';
import type { CoreOperation } from '../../../types/coreData';

const WORKFLOW_MIN_INTERVAL_MS = 2_500;

export interface UseGatheringWorkflowInput {
  groupId: string | null;
  userId: string | undefined;
  myScopeId: string | undefined;
  isMainLeader: boolean;
  isSubgroupLeader: boolean;
  canEditItinerary: boolean;
  t: (key: TranslationKey) => string;
  /** My queued arrival intents; acked receipts are compacted once the server reflects them. */
  arrivalOperations: CoreOperation[];
  arrivalSessionScope: string[];
  rawDestinations: Destination[];
}

/**
 * Remote arrival rows and the leader's pending gather-point requests for my
 * scope: single-flight loads, Realtime-coalesced reloads, and compaction of
 * my acknowledged arrival receipts once the server reflects them.
 */
export function useGatheringWorkflow({
  groupId,
  userId,
  myScopeId,
  isMainLeader,
  isSubgroupLeader,
  canEditItinerary,
  t,
  arrivalOperations,
  arrivalSessionScope,
  rawDestinations,
}: UseGatheringWorkflowInput) {
  const [remoteArrivals, setDestinationArrivals] = useState<DestinationArrival[]>([]);
  const [gatherPointRequests, setGatherPointRequests] = useState<GatherPointRequest[]>([]);
${block}
  return {
    remoteArrivals,
    gatherPointRequests,
    setGatherPointRequests,
    loadGatheringWorkflow,
    patchLocalArrival,
    /** \`group:user:scope\`; async work started under one context must not land in another. */
    workflowContext,
    isWorkflowContextCurrent: useCallback((context: string) => mountedRef.current
      && workflowContextRef.current === context, []),
  };
}
`;
fs.writeFileSync('src/screens/MapScreen/hooks/useGatheringWorkflow.ts', hook);
s = s.slice(0, i) + `  useForegroundReconcile(Boolean(groupId), recoverPendingLocationRefreshes);
  const mapMountedRef = useRef(true);
  useEffect(() => {
    mapMountedRef.current = true;
    return () => { mapMountedRef.current = false; };
  }, []);
` + s.slice(j);
// State + hook call where remoteArrivals was declared.
const stateLine = '  const [remoteArrivals, setDestinationArrivals] = useState<DestinationArrival[]>([]);\n';
if (!s.includes(stateLine)) throw new Error('state line');
s = s.replace(stateLine, '');
const scopeStart = s.indexOf('  const arrivalSessionScope = useMemo(');
const scopeEnd = s.indexOf('    [localNavigationSessionId, navigationSessionId],\n  );\n', scopeStart) + '    [localNavigationSessionId, navigationSessionId],\n  );\n'.length;
const scopeBlock = s.slice(scopeStart, scopeEnd);
s = s.slice(0, scopeStart) + s.slice(scopeEnd);
const anchor = '  const destinationArrivals = useMemo(() => projectPersonalArrivals(remoteArrivals';
const k = s.indexOf(anchor);
if (k < 0) throw new Error('anchor');
s = s.slice(0, k) + scopeBlock + `  const {
    remoteArrivals,
    gatherPointRequests,
    setGatherPointRequests,
    loadGatheringWorkflow,
    patchLocalArrival,
    workflowContext,
    isWorkflowContextCurrent,
  } = useGatheringWorkflow({
    groupId,
    userId: user?.id,
    myScopeId,
    isMainLeader: isLeader,
    isSubgroupLeader: isMySubgroupLeader,
    canEditItinerary,
    t,
    arrivalOperations,
    arrivalSessionScope,
    rawDestinations,
  });
` + s.slice(k);
const gpr = '  const [gatherPointRequests, setGatherPointRequests] = useState<GatherPointRequest[]>([]);\n';
if (!s.includes(gpr)) throw new Error('gpr');
s = s.replace(gpr, '');
const wr = '  const workflowReloadRef = useRef<ReturnType<typeof setTimeout> | null>(null);\n';
if (!s.includes(wr)) throw new Error('wr');
s = s.replace(wr, '');
s = s.replace("    const context = workflowContext;\n    const isCurrent = () => mapMountedRef.current && workflowContextRef.current === context;\n",
  "    const context = workflowContext;\n    const isCurrent = () => isWorkflowContextCurrent(context);\n");
s = s.replace("    refreshLocalSnapshot, stopRemovedDestination, t, workflowContext]);", "    refreshLocalSnapshot, stopRemovedDestination, t, workflowContext, isWorkflowContextCurrent]);");
s = s.replace("import { useGroupRole } from './MapScreen/hooks/useGroupRole';\n",
  "import { useGatheringWorkflow } from './MapScreen/hooks/useGatheringWorkflow';\nimport { useGroupRole } from './MapScreen/hooks/useGroupRole';\n");
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok', block.split('\n').length);
