const fs = require('fs');
const stylesPath = 'src/screens/MapScreen/styles.ts';
const header = `import { Platform, StyleSheet } from 'react-native';
import { accentMix, glass } from '../../glass';
import { COUNTDOWN_WIDTH_FACTOR, GATHER_CMD_MIN_HIT_PT } from '../../utils/gatherCommandLayout';
import { applyAppTextScale, applyBoldTextWeights } from '../../utils/styleScaling';
import { STATUS_SHARE_CLUSTER_GAP } from './memberStatusSharing';

/** The design's display face — Fredoka (loaded in App.tsx). Used for
 * gathering-point titles, ETA numerals and the set-gather-time. */
export const DISPLAY_FONT = 'Fredoka_600SemiBold';
export const PASSIVE_ENTER_HEIGHT = 65; // round(162 * 0.4)

`;
fs.writeFileSync(stylesPath, header + fs.readFileSync(stylesPath, 'utf8'));
const mapPath = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(mapPath, 'utf8').replace(/\r\n/g, '\n');
const rm = (a) => { if (!s.includes(a)) throw new Error('missing ' + a.slice(0, 50)); s = s.replace(a, ''); };
rm(`const PASSIVE_ENTER_HEIGHT = 65; // round(162 * 0.4)\n`);
const dispStart = s.indexOf('/** The design\'s display face');
const dispEnd = s.indexOf("const DISPLAY_FONT = 'Fredoka_600SemiBold';\n") + "const DISPLAY_FONT = 'Fredoka_600SemiBold';\n".length;
if (dispStart < 0 || dispEnd < dispStart) throw new Error('display font block');
s = s.slice(0, dispStart) + s.slice(dispEnd).replace(/^\n/, '');
s = s.replace(`import { useGroupRole } from './MapScreen/hooks/useGroupRole';\n`,
  `import { useGroupRole } from './MapScreen/hooks/useGroupRole';\nimport { DISPLAY_FONT, makeStyles, PASSIVE_ENTER_HEIGHT } from './MapScreen/styles';\n`);
fs.writeFileSync(mapPath, s.replace(/\n/g, '\r\n'));
console.log('ok');
