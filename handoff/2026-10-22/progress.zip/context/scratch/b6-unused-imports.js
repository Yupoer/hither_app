// Remove named/default import bindings by name from a TS file's import declarations.
// Usage: node b6-unused-imports.js <file> name1 name2 ...
const fs = require('fs');
const [file, ...names] = process.argv.slice(2);
const raw = fs.readFileSync(file, 'utf8');
const eol = raw.includes('\r\n') ? '\r\n' : '\n';
let s = raw.replace(/\r\n/g, '\n');
const drop = new Set(names);
const removed = new Set();
s = s.replace(/^import (type )?([\s\S]*?) from (['"][^'"]+['"]);\n/gm, (whole, typeKw, clause, from) => {
  let def = null;
  let named = null;
  const m = clause.match(/^([A-Za-z_$][\w$]*)?\s*,?\s*(\{[\s\S]*\})?$/);
  if (!m) return whole;
  def = m[1] ?? null;
  named = m[2] ?? null;
  if (def && drop.has(def)) { removed.add(def); def = null; }
  let specs = [];
  if (named) {
    specs = named.slice(1, -1).split(',').map((x) => x.trim()).filter(Boolean);
    specs = specs.filter((spec) => {
      const local = spec.replace(/^type\s+/, '').split(/\s+as\s+/).pop().trim();
      if (drop.has(local)) { removed.add(local); return false; }
      return true;
    });
  }
  if (!def && specs.length === 0) return '';
  const multiline = named && named.includes('\n');
  const namedOut = specs.length === 0 ? '' : multiline
    ? `{\n${specs.map((x) => `  ${x},`).join('\n')}\n}`
    : `{ ${specs.join(', ')} }`;
  const parts = [def, namedOut].filter(Boolean).join(', ');
  return `import ${typeKw ?? ''}${parts} from ${from};\n`;
});
fs.writeFileSync(file, s.replace(/\n/g, eol));
const missing = names.filter((n) => !removed.has(n));
console.log('removed', [...removed].join(','), missing.length ? 'NOT FOUND ' + missing.join(',') : '');
