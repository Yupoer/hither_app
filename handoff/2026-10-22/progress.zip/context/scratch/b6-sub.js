const fs = require('fs');
const p = 'src/screens/MapScreen.tsx';
let s = fs.readFileSync(p, 'utf8').replace(/\r\n/g, '\n');
const cut = (startText, endText, replacement = '') => {
  const i = s.indexOf(startText);
  if (i < 0) throw new Error('start missing: ' + startText.slice(0, 60));
  const j = s.indexOf(endText, i);
  if (j < 0) throw new Error('end missing: ' + endText.slice(0, 60));
  s = s.slice(0, i) + replacement + s.slice(j + endText.length);
};
cut("  // Invites I've sent for my subgroup that are still pending", "      // best-effort\n    }\n  }, []);\n");
cut('  // --- Subgroups (', `      logError('team_leave_failed', e, { groupId });
      Alert.alert(t('subgroup.failed'), e instanceof Error ? e.message : undefined);
      return false;
    }
  }, [groupId, refresh, t]);
`, `  // --- Subgroups (小隊：邀請制；依 leader_id 判斷小隊隊長) --------------------
  const setRouteDraftDestinations = routeDraft.setDestinations;
  const {
    subgroups,
    pendingInvites,
    sentInvites,
    handleAcceptInvite,
    handleDeclineInvite,
    handleInvite,
    doSelfSplit,
    doSelfMerge,
  } = useSubgroupActions({
    groupId,
    userName: user?.name,
    members,
    allSubgroups: state?.subgroups,
    mySubgroupId: myScopeId,
    refresh,
    t,
    onMergedBack: useCallback(() => {
      // Leave wipes subgroup-scoped UI: itinerary draft list, team pill scope.
      setRouteDraftDestinations(null);
      setViewingScope('main');
    }, [setRouteDraftDestinations]),
  });
`);
cut('  useEffect(() => {\n    void refreshSentInvites(mySubgroupId);', '  }, [mySubgroupId, refreshSentInvites, sentInvites.length, members.length]);\n');
s = s.replace("import { useGroupRole } from './MapScreen/hooks/useGroupRole';\n",
  "import { useGroupRole } from './MapScreen/hooks/useGroupRole';\nimport { useSubgroupActions } from './MapScreen/hooks/useSubgroupActions';\n");
const warn = "/** Persisted \"don't warn me again\" flag for the leave-the-main-group notice. */\nconst LEAVE_GROUP_WARN_KEY = 'hither.subgroupLeaveWarnDismissed';\n\n";
if (!s.includes(warn)) throw new Error('warn key');
s = s.replace(warn, '');
fs.writeFileSync(p, s.replace(/\n/g, '\r\n'));
console.log('ok');
