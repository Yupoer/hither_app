const fs = require('fs');
const stylesSrc = fs.readFileSync('src/screens/MapScreen/styles.ts', 'utf8');
const edit = (p, fn) => {
  const raw = fs.readFileSync(p, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const lines = raw.replace(/\r\n/g, '\n').split('\n');
  fn(lines);
  fs.writeFileSync(p, lines.join('\n').replace(/\n/g, eol));
};
const swap = (lines, lineNo, from, to) => {
  const i = lineNo - 1;
  if (!lines[i].includes(from)) throw new Error(`line ${lineNo} lacks ${from}: ${lines[i]}`);
  lines[i] = lines[i].split(from).join(to);
};
const insertAfter = (lines, pred, text) => {
  const i = lines.findIndex(pred);
  if (i < 0) throw new Error('anchor');
  lines.splice(i + 1, 0, text);
};
const T = 'src/__tests__/';
edit(T + 'mapStatusSettingsPaywall.test.ts', (l) => {
  swap(l, 76, 'exec(mapScreen)', 'exec(mapStyles)');
  swap(l, 78, 'exec(mapScreen)', 'exec(mapStyles)');
  insertAfter(l, (x) => x.startsWith("const mapScreen = read('screens/MapScreen.tsx');"),
    "const mapStyles = read('screens/MapScreen/styles.ts');");
});
edit(T + 'mapUiContracts.test.ts', (l) => {
  swap(l, 459, "mapScreen.indexOf('myStatusTriggerInner:')", "mapStyles.indexOf('myStatusTriggerInner:')");
  swap(l, 460, 'mapScreen.slice(', 'mapStyles.slice(');
});
edit(T + 'mapChromeUiContract.test.ts', (l) => {
  for (const n of [29, 30, 37, 38, 39, 40]) swap(l, n, 'expect(map)', 'expect(mapStyles)');
  l.splice(35, 0, "    const mapStyles = read('screens/MapScreen/styles.ts');");
  l.splice(23, 0, "    const mapStyles = read('screens/MapScreen/styles.ts');");
});
edit(T + 'amicroUiContracts.test.ts', (l) => {
  for (const n of [30, 31, 70]) swap(l, n, 'expect(map)', 'expect(mapStyles)');
  l.splice(9, 0, "  const mapStyles = read('screens/MapScreen/styles.ts');");
});
edit(T + 'memberStatusSharing.test.ts', (l) => {
  for (const n of [85, 86, 87, 88, 89, 90, 100, 101, 102, 103]) {
    const lit = l[n - 1].match(/toContain\((.*)\);/)[1];
    // eslint-disable-next-line no-new-func
    if (stylesSrc.includes(Function(`return ${lit}`)())) swap(l, n, 'expect(mapScreen)', 'expect(mapStyles)');
  }
  l.splice(12, 0, "const mapStyles = readFileSync(join(__dirname, '..', 'screens', 'MapScreen', 'styles.ts'), 'utf8');");
});
edit(T + 'arrivalFeedbackContract.test.ts', (l) => {
  swap(l, 81, 'source.slice(', 'mapStyles.slice(');
  swap(l, 82, 'source.indexOf(', 'mapStyles.indexOf(');
  swap(l, 83, 'source.indexOf(', 'mapStyles.indexOf(');
});
console.log('ok');
