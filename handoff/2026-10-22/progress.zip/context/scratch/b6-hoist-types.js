// Turn inline `import("mod").Name` type references into top-level `import type` lines.
const fs = require('fs');
for (const file of process.argv.slice(2)) {
  const raw = fs.readFileSync(file, 'utf8');
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  let s = raw.replace(/\r\n/g, '\n');
  const wanted = new Map(); // mod -> Set(names)
  const declared = new Set([...s.matchAll(/^import[^;]*?\{([^}]*)\}/gm)].flatMap((m) => m[1].split(',').map((x) => x.replace(/\btype\b/, '').split(/\s+as\s+/).pop().trim())));
  for (const m of s.matchAll(/^import (\w+)/gm)) declared.add(m[1]);
  let skipped = 0;
  s = s.replace(/import\("([^"]+)"\)\.(\w+)/g, (whole, mod, name) => {
    const already = declared.has(name);
    const owner = [...wanted.entries()].find(([, names]) => names.has(name));
    if ((already && !(wanted.get(mod)?.has(name))) || (owner && owner[0] !== mod)) {
      // Keep inline when the bare name is already taken by another binding.
      if (!(already && [...s.matchAll(new RegExp(`from '${mod.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}'`, 'g'))].length)) { skipped++; return whole; }
      return name;
    }
    if (!wanted.has(mod)) wanted.set(mod, new Set());
    wanted.get(mod).add(name);
    return name;
  });
  const lines = [...wanted].map(([mod, names]) => `import type { ${[...names].sort().join(', ')} } from '${mod}';`);
  if (lines.length) {
    const lastImport = [...s.matchAll(/^import .*;$/gm)].pop();
    const at = lastImport.index + lastImport[0].length;
    s = s.slice(0, at) + '\n' + lines.join('\n') + s.slice(at);
  }
  fs.writeFileSync(file, s.replace(/\n/g, eol));
  console.log(file, 'hoisted', lines.length, 'skipped', skipped);
}
