# Re-review: hither_app branch claude/b3-backend-correctness, round 2

Review only; do not modify files. Round 1 report: C:\Users\alex.shen\.claude\jobs\0e588e88\tmp\blocks\review-b3.out (P1 grant/refund race, P2 REFUND_REVERSED, P2 navigation control aggregation). New commits 537f350 and c7344c8 (`git diff ee6ddc2..HEAD`):
- lock_trip_storekit_transaction: pg_advisory_xact_lock on the original transaction id, taken first by both RPCs; two-connection regression supabase/tests/trip_storekit_refund_concurrency.mjs wired into CI after promo_redemption_concurrency.mjs.
- trip_store_revocation_status derives refund state from the accepted notification ledger by signedDate; REFUND_REVERSED reinstates a refunded pass in its original window unless another active trip pass exists in the group; the pre-grant block uses the same helper; the notification RPC signature dropped p_status.
- withControlDelivery merges navigation control pushes into status and providerFailures; new controlSent/controlTotal counters.

Local evidence: in PGlite (PostgreSQL 17 in process) all migrations apply; trip_storekit_revocation 33/33 and storekit_purchase_ledger 29/29 pass; no new pgTAP failures vs master. Deno suite 105 passed. The race script has not run anywhere.

Check:
1. Are the three round-1 findings closed?
2. Lock ordering across every function that touches small trip pass entitlements, notifications or group rows (including existing ones not in this diff), deadlock risk, and whether the race script really exercises the interleaving and cleans up on failure.
3. Reinstatement semantics vs Apple's REFUND_REVERSED docs, signedDate tie and ordering rules, expiry handling, idempotency on replays, and the dropped p_status argument (old function overload left behind? any caller still passing it?).
4. Anything else in the whole branch.

Rank findings by severity with file:line and a concrete failure. End with APPROVE or CHANGES REQUESTED.
