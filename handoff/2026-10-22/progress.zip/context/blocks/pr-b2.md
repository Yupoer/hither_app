This PR cuts down how much work the app repeats while a group trip is open: needless map re-renders, group reloads triggered by unrelated users' profile edits, and an aggressive fallback poll. It is stacked on #312, so CI's Expo drift check passes.

**What changes for users**
- `GroupMap` gets a memoized destinations array. Before, `MapScreen` built a new array every render, so `React.memo(GroupMap)` never skipped. During navigation, location-driven renders happen every 250–500 ms. That frequency is inferred from the timers, not profiled.
- Profile realtime is a separate channel filtered with `id=in.(<co-member ids>)`. It resubscribes only when the member set changes. Before, any profile UPDATE the client could see triggered a full group reload.
- The full group reload polls every 30 s while realtime is down and every 120 s while the channel is SUBSCRIBED. Repeated rejoin errors no longer push the 30 s fallback back, and a poll never overlaps an in-flight load.
- `shouldAcceptUiSample` drops a dead branch. Its behavior is unchanged: the effective threshold is still 40% of `uiMinDistanceM`.
- Removes the unused `react-native-draggable-flatlist`, which is pure JS and has no native pod.

**Tried and reverted**
- Batching non-journey foreground location uploads was reverted in this PR. Review showed that handing off the batch on teardown could purge a queued fix once access was revoked, and the battery gain was never measured. Foreground uploads stay immediate, as on master.

**Not done**
- `react-native-view-shot` is unused but native, so removing it needs a new binary.
- The Swift Live Activity update dedupe was not done because Swift cannot be compiled here.
- The other independent 30 s timers were not consolidated.

**Verification**
- jest: 334 suites, 2790 tests.
- tsc clean.
- `test:meta` with `META_PARENT=304` PASS.
- Changed-function coverage: 91.42%.
- `verify:runtime` ok.
- `expo install --check` up to date.
- New hook-level tests use a fake realtime channel. The cadence tests were confirmed to fail on the pre-fix code.
- Codex reviewed three rounds and approved round 3.
- Not tested on a device or against a live Supabase realtime server.

Closes #304

<!-- hither-test-meta parent: 304 -->

🤖 Generated with [Claude Code](https://claude.com/claude-code)
