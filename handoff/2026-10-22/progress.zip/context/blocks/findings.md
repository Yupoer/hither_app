# hither_app review findings (source of truth for fix blocks)

Repo: Yupoer/hither_app, default branch master. Baseline at origin/master: `npx tsc --noEmit` clean, `npx jest` 333 suites / 2787 tests pass (~13 s), both run from apps/mobile.
No Docker/WSL on this machine, so pgTAP (`supabase test db`) cannot run locally. GitHub CI (.github/workflows/ci.yml) runs pgTAP on every PR and is the SQL verifier.

## B2 perf quick wins
- MapScreen.tsx:7050 passes `destinations={[...allScopedDestinations.filter(...), ...destinations]}` inline, defeating React.memo(GroupMap) (GroupMap.tsx:1159).
- useGroupState.ts:690-694 subscribes to `profiles` UPDATE with no filter; every visible profile change triggers a full group reload.
- useGroupState.ts:52,709-716 full reload poll every 30 s even when realtime is SUBSCRIBED (realtimeReadyRef exists). Comment at 683-685 says "5-minute poll".
- ~9 independent 30 s timers (useNavigationSession.ts:138, useOrganizerExceptions.ts:146,281, useDeviceLocation.ts:346, useForegroundReconcile x5, invites 15 s MapScreen.tsx:5639).
- useDeviceLocation.ts:247-252 foreground uploads always `immediate: true`, bypassing batched scheduleOutboxFlush.
- locationPolicy.ts:293-296 `moved >= uiMinDistanceM*0.4` makes the preceding `>= uiMinDistanceM` check dead; effective threshold 40%.
- Unused deps: react-native-view-shot, react-native-draggable-flatlist (no imports in src).
- HitherLiveActivityModule.swift:55-66 always calls activity.update even when merged state unchanged.

## B3 backend correctness
- apple-server-notifications/index.ts:203 only validates subscriptions (validateStoreKitTransaction); REFUND/REVOKE of the trip-pass product (granted in verify-and-apply-purchase/index.ts:198-235 via validateStoreKitTripTransaction) returns 422 and the entitlement is never revoked. TEST notifications without transaction info also 422.
- supabase/config.toml:385-405 has no [functions.send-push] block, so verify_jwt defaults true; extensions.notify_push (migrations/20260716200000_gather_resolve_hardening.sql:5-45) sends only x-hither-webhook-secret, swallows errors.
- send-push/index.ts: provider sends via Promise.all; FCM error after APNs sent turns whole response to 500 (:226-229, :440-444, :492-496).
- admob-reward-callback/ssv.ts:113-141 reads params from the whole query, not only the signed content; finds signature with first indexOf("signature=").
- group_member_count(uuid) (migrations/20260725000100_paid_entitlement.sql:227-240) is callable by any authenticated user for any group.
- set_destination_arrival_at (20260716000000_arrival_time_choices.sql:94-130) writes unbounded client p_arrived_at.
- core_operations.actor_id (20260725000200_core_operation_sync.sql:21-42) has FK ON DELETE CASCADE but no index.

## B4 test gates
- ci.yml:191-208 runs only 18 of 36 supabase/tests/*.test.sql. Excluded include silent_journey_sync_v3, silent_journey_sync_compat, silent_sync_integration, idempotent_navigation_end, leader_gathering_switch, paid_entitlement, rewarded_ads_token_store, import_itinerary_batch, team_navigation_sessions.
- 127 of ~339 jest files readFileSync production source and assert strings (3184 toContain). 65 import no production code. scripts/check-test-meta.mjs:113-135 exempts *Contract* files.

## B5 sync engine source of truth
- apply_core_operation_v3 (~1600 lines) defined at migrations/20260920062819_silent_journey_sync_v3.sql:821, redefined at 20260922000100_idempotent_navigation_end.sql:2, then patched by text replace() over pg_get_functiondef in: 20261001115316_durable_trip_daily_accommodation.sql:25, 20261002061447_security_group_command_import_arrival_bounds.sql:566-578, 20261002113231_quick_add_first_stop.sql:68, 20261004010000_durable_solo_and_refresh_receipts.sql:5, 20261009132855_preserve_durable_reorder_optional_fields.sql:25. core_itinerary_state similar (20260726000000_anonymous_expiry_is_member.sql:357).
- v1 apply_core_operation (last def 20260919090000_unscheduled_destination_pool.sql:895) still granted to authenticated; v2 wrapper in 20260920062819...:2615-2722; client calls v3 (api/services/CoreDataService.ts:86) and v1 (:134-136).

## B6 MapScreen
- MapScreen component spans MapScreen.tsx:508-9278 with ~82 useState, ~60 useEffect, ~85 useRef, ~103 useCallback, ~54 useMemo. Sections: sheet/overlay UI (:1244), meet-time editor (:1657), carousel (:1923), journey nav + Live Activity (:1945), straggler alerts (:3131), group actions (:4478), profile (:4521), solo (:4545), subgroups/invites (:4567), derived view models (:5408), arrival enqueue (:2553), journey completion (:4093), itinerary mutations (:5214), role/kick detection (:625-720). makeStyles :9813-11540.
- 33 `useRef(x)` mirrors + 104 `xRef.current =` assignments.
- Duplicate optimistic itinerary state: optimisticDestinations, draftDailyAccommodations, pendingDestinationMutations, optimisticTripDays, optimisticDepartureDate (:754,774,778,895-896), own rollback (:866-893), utils/destinationMutationOverlay.ts, while coreOperationOutbox/coreOperationProjection already project and roll back.
- Role from three sources: session membership.role, group state me.role, local revokedLeaderContext; isLeader blends (:650-651); effect writes back (:654-656).
- Many contract tests (e.g. mapUiContracts.test.ts) assert literal MapScreen source lines.
