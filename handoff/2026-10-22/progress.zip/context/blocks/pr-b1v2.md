This PR is stacked on #312 so CI's Expo drift check passes. It replaces #310, which was based on master.

Removes agent state that was committed by accident and tightens what CI and the Claude Fix workflow are allowed to do.

**Repo hygiene**
- Deletes `.superpowers/` (brainstorm server state: pid, logs and a local Windows path), `apps/mobile/mcps/` (44 MCP tool schemas) and the one-off `apps/mobile/generate_report.js`. `.gitignore` now ignores `.superpowers/` and `mcps/`.
- Pins `@react-native-google-signin/google-signin` to exactly 16.1.4, the version its patch targets.
- Updates the README stack line to Expo SDK 57 / RN 0.86.

**CI**
- `ci.yml` and `regen-ios-pods.yml` default the token to `contents: read`. `open-issue` keeps its job-level `issues: write`.
- Every action is pinned to a commit SHA on its current major.

**Claude Fix workflow**
- The agent job runs with `contents: read` and `issues: read`. Its tool list no longer allows push, PR creation or merge. Its commits are bundled into an artifact.
- A separate `publish` job starts from a fresh master checkout and takes the starting commit from the agent job's outputs. It checks that the bundle descends from that commit, pushes with hooks disabled to `claude-fix/issue-<n>-<run>-<attempt>`, and opens a draft PR carrying the `hither-test-meta` marker.
- This split came from three rounds of Codex review. The narrower tool list alone still let agent-run npm scripts push with the token the action configures.

**Verification**
- Local: jest 333/333 suites and 2787 tests; `test:meta` PASS; `verify:runtime` ok; all workflow YAML parses; the run scripts pass `bash -n`.
- Codex reviewed four rounds and approved round 4.
- Not exercised: a live dispatch of Claude Fix, because each run is a billed API call.

<!-- hither-test-meta parent: pure-chore -->

🤖 Generated with [Claude Code](https://claude.com/claude-code)
