# Block B7: ban useEffect

Operator directive: forbid useEffect everywhere in apps/mobile/src and replace every use.

Baseline at origin/master: 219 `useEffect(` calls in 59 non-test files (MapScreen.tsx 60, useJourneyNavigation.ts 15, useDeviceLocation.ts 10, useLiveActivity.ts 8, GroupMap.tsx 8, ...). This block runs on top of the B2 (perf) and B6 (MapScreen decomposition) branches, so counts will differ; recount first.

Replacement table, in order of preference:
1. Derived state: an effect that sets state from props/state becomes a value computed during render (useMemo only if expensive).
2. Event-driven work: an effect that reacts to a state change caused by a user action moves into that action's handler.
3. Reset on identity change: an effect that resets state when an id changes becomes a `key` on the component, or a "previous value" comparison during render.
4. External store reads (AppState, Appearance, NetInfo, module-level stores, coreDataStore): useSyncExternalStore with a subscribe function.
5. Data fetching: an existing query/loader hook if the codebase has one; otherwise an explicit loader called from the event or mount point.
6. Genuine external synchronization (native listeners, timers, realtime channels, Live Activity, location subscriptions): the sanctioned escape hatch `useMountEffect(fn)` in src/hooks/useMountEffect.ts, a thin wrapper around useEffect with an empty dependency array. When the synchronization depends on a changing value, lift that value into a child component keyed by it, so the child mounts and unmounts with it, and put useMountEffect in the child; or subscribe once and read the latest value from a ref inside the callback.

Gate: ESLint `no-restricted-imports` / `no-restricted-syntax` forbidding `useEffect` and `useLayoutEffect` from 'react' (and `React.useEffect`) everywhere except src/hooks/useMountEffect.ts. Add it to apps/mobile/eslint.config.js so `npx expo lint` fails on reintroduction.

Rules:
- Behavior preserved. Each file converted is its own commit (or a small group), green on tsc + jest before the next.
- Effects whose dependency arrays include changing values need extra care: converting them to mount-only is a behavior change unless you restructure as in rule 6. Never silently drop a dependency.
- Tests that pin `useEffect(` in source text get updated or replaced with behavior tests.
- Report a table: file, effects before, how each was replaced (rule number), and any left on useMountEffect with the reason.
