import { readFileSync, writeFileSync } from 'node:fs';

const [mapPath, entriesPath] = process.argv.slice(2);
const text = readFileSync(mapPath, 'utf8');
const eol = text.includes('\r\n') ? '\r\n' : '\n';
const entries = JSON.parse(readFileSync(entriesPath, 'utf8'));
const close = text.lastIndexOf(`${eol}  ]`);
if (close < 0) throw new Error('entries array close not found');
const lines = entries.map(e => `    ${JSON.stringify(e).replace(/":/g, '": ').replace(/,"/g, ', "')}`);
const next = `${text.slice(0, close)},${eol}${lines.join(`,${eol}`)}${text.slice(close)}`;
JSON.parse(next);
writeFileSync(mapPath, next);
console.log(`added ${entries.length} entries`);
