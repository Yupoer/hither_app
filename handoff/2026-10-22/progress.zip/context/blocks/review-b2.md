# Code review: hither_app branch claude/b2-perf

You are reviewing, not fixing. Do not modify any file. Diff: `git diff origin/master...HEAD` (4 commits).

Intent (React Native + Supabase app, apps/mobile):
1. Memoize the destinations array passed to React.memo(GroupMap) in MapScreen.tsx.
2. useGroupState.ts: move the `profiles` realtime UPDATE binding to its own channel filtered `id=in.(<co-member ids>)`, resubscribing only when the id set changes.
3. useGroupState.ts: full-reload poll is 30 s while the group channel is not SUBSCRIBED and 120 s while it is; re-armed on each status change.
4. useDeviceLocation.ts / locationPolicy.ts: foreground fixes upload immediately only in `journey` power mode; otherwise batched via scheduleOutboxFlush (20 s).
5. locationPolicy.ts: remove a dead branch, behavior unchanged.
6. Remove unused dependency react-native-draggable-flatlist.

Look hard for:
- Realtime correctness: Supabase postgres_changes `in` filter syntax for uuid columns, RLS on profiles for realtime, a race where the profiles channel captures a stale scheduleReloadRef, missed reload when members change while backgrounded, channel leaks on fast group switches.
- Poll scheduling: overlapping timers, a poll that never re-arms after a thrown load, behavior across appState changes, unmount during an in-flight load.
- Location: any path where a non-journey upload is now delayed indefinitely (app backgrounded before the 20 s flush, outbox flush cancelled on unmount), and whether journey mode is set in every navigation state that needs live sharing (e.g. followers during a leader's navigation, arrival detection server-side).
- Whether the new tests would actually fail if the behavior broke.
- Anything that still imports or configures react-native-draggable-flatlist (babel, metro, jest mocks).

Rank findings by severity with file:line and a concrete failure scenario. End with APPROVE or CHANGES REQUESTED.
