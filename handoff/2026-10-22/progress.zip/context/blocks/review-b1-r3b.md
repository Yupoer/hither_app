# CI configuration review: hither_app branch claude/b1-hygiene

Review only; do not modify files. Focus on `.github/workflows/claude-fix.yml` as changed by the latest commit (`git diff HEAD~1..HEAD`), plus anything else in `git diff origin/master...HEAD`.

Design goal of the latest commit: the job that runs the coding assistant has read-only repository permissions and produces a git bundle artifact; a second job with write permissions starts from a fresh checkout of master, imports only the commits from that bundle, checks they descend from the recorded starting commit, pushes them to a new branch with git hooks disabled, and opens a draft pull request whose body carries the `hither-test-meta parent:` marker that ci.yml requires.

Please confirm or refute, with file:line:
1. Write permissions (contents: write, pull-requests: write) exist only in the publish job, and the publish job consumes nothing from the first job except the uploaded artifact (start-sha file and bundle). Is each consumed input validated before use?
2. Will anthropics/claude-code-action at the pinned commit function with only contents: read and issues: read, given the workflow's prompt-driven agent mode?
3. Is the publish script correct: bundle verification with fetch-depth 0, fetching HEAD from a bundle created from `start..HEAD`, the push refspec, the no-commit path, rerun behavior, and the PR body text and marker formatting?
4. Any regression elsewhere in the branch diff.

Rank findings by severity with file:line and the concrete failure. End with APPROVE or CHANGES REQUESTED.
