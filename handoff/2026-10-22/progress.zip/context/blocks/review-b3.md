# Code review: hither_app branch claude/b3-backend-correctness

Review only; do not modify files. Diff: `git diff origin/master...HEAD` (7 commits). Supabase backend: SQL migrations + pgTAP tests + Deno edge functions. pgTAP has not been executed anywhere yet (no Docker locally; CI will run it), so read the SQL as if you were the database.

Changes:
1. apple-server-notifications: trip-pass product REFUND/REVOKE now marks the pass refunded/revoked through a new service_role RPC `apply_trip_storekit_notification` (migration 20261022100000); `apply_verified_trip_storekit_purchase` redefined to refuse transactions with an accepted REFUND/REVOKE; TEST notifications return 200.
2. supabase/config.toml: send-push verify_jwt = false; secret check in send-push/auth.ts.
3. send-push/delivery.ts: per-provider and per-recipient failure isolation; 500 only when no provider answered.
4. admob-reward-callback/ssv.ts: fields read only from the signed portion; signature and key_id must be the final parameters.
5. group_member_count requires membership for signed-in callers (20261022100100).
6. set_destination_arrival_at bounds p_arrived_at to [now-30d, now+5m] (20261022100200).
7. Index on core_operations(actor_id) (20261022100300).

Check correctness:
- SQL: does each migration apply cleanly on top of the existing history (exact signatures for CREATE OR REPLACE, grants re-applied, search_path = '', SECURITY DEFINER where the originals had it)? Does the redefined apply_verified_trip_storekit_purchase preserve every behavior of its latest prior definition apart from the added check? Will each pgTAP test pass (role switching, plan counts, fixtures)?
- StoreKit: notification types and subtypes mapped correctly per Apple's App Store Server Notifications v2; idempotency on retries; ordering when REFUND arrives before purchase verification.
- send-push: response shape compatibility for existing callers (SQL notify_push and any client), status code semantics, dead-token pruning still happens.
- AdMob SSV: matches Google's server-side verification spec for parameter order and encoding; no valid callback now rejected.
- group_member_count / set_destination_arrival_at: every existing caller (SQL functions, RLS policies, client, .mjs scripts under supabase/tests) keeps working.

Rank findings by severity with file:line and the concrete failure. End with APPROVE or CHANGES REQUESTED.
