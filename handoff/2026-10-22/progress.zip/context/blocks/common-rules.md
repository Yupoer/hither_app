# Rules for every fix block

- poteto-mode skill: C:\Users\alex.shen\.claude\plugins\cache\cursor-plugins\pstack\0.15.29\skills\poteto-mode\SKILL.md
- Findings: C:\Users\alex.shen\.claude\jobs\0e588e88\tmp\blocks\findings.md. Verify every finding against the code before fixing it; if one is wrong, skip it and say why.
- Work only inside your assigned worktree. Its branch is already checked out from origin/master. Never touch other worktrees or the main clone at tmp\hither_app.
- apps/mobile/node_modules is a junction shared by six worktrees. Never run `npm install`, `npm ci`, `npx patch-package`, or anything that writes into node_modules. To change dependencies, edit package.json and run `npm install --package-lock-only --ignore-scripts --no-audit --no-fund`.
- Verify from apps/mobile: `npx tsc --noEmit`, `npx jest --silent`, `node scripts/check-test-meta.mjs`. All must stay green; baseline is 333 suites / 2787 tests passing. Run `npx eslint` on files you touched.
- SQL cannot run locally (no Docker). CI runs pgTAP on the PR. Write SQL carefully, mirror patterns from neighboring migrations, and add or extend a pgTAP test in supabase/tests for each SQL behavior change.
- Edge functions are Deno. `npx -y deno@2 test --allow-all <dir>` and `npx -y deno@2 check <file>` work without a global install.
- Behavior-preserving unless the finding is a bug. For a user-visible product tradeoff, pick the conservative default and list it under "Decisions" in your report.
- No data deletion, no deploys, no pushes, no PRs. Commit on your branch with conventional messages, each ending with a blank line and `Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>`.
- Tests assert observable behavior. Do not add new tests that readFileSync production source and match strings.
- Comments only for a non-obvious why.
- Final report: what you changed per finding (fixed / skipped + reason), decisions, verification commands with their result lines, residual risks, and `git log --oneline origin/master..HEAD`.
