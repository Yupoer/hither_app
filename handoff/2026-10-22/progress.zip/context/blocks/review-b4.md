# Code review: hither_app branch claude/b4-sql-test-gate

Review only; do not modify files. Diff: `git diff origin/master...HEAD` (2 commits).

Changes:
1. .github/workflows/ci.yml: pgTAP step runs every supabase/tests/*.test.sql in a loop, collecting failures, instead of 18 hand-listed files. 18 previously unexecuted test files were edited so they pass against current migrations (stale fixtures: non-hex UUIDs, expiry write gate, row counts, error codes, session switch semantics; paid_entitlement and rewarded_ads_token_store rewritten from comment-only notes into real tests). Migrations were not changed.
2. apps/mobile/scripts/check-test-meta.mjs: a ratchet that fails when a new jest test reads production source via readFileSync without importing production code, against baseline apps/mobile/scripts/source-only-tests-baseline.json (60 files). Unit tests in src/__tests__/sourceOnlyTestRatchet.test.ts.

Local evidence: with an in-process PostgreSQL 17 (PGlite) applying all 115 migrations and shimmed pgTAP helpers, 34 of 36 files pass. daily_accommodations_expiry_leader needs dblink (unavailable there). security_group_command_import_arrival fails there with "invalid input syntax for type json" on master too, though it is in master's CI list; treat that as a PGlite difference unless you find otherwise.

Check:
- For each edited test: did the edit adapt the test to current intended behavior, or did it weaken an assertion so a real product defect now passes? Compare against the migrations that define the behavior; call out any assertion that was loosened, removed, or flipped to match buggy behavior (e.g. the P0002-vs-42501 change in itinerary_position_serialization, the outsider 42501 change in team_navigation_sessions, the coordination override no longer moving coordinates).
- The new paid_entitlement and rewarded_ads_token_store tests: do they assert the real contract?
- daily_accommodations_expiry_leader uses dblink and COMMITs fixtures: will it pass and clean up under `supabase test db --local` in CI?
- CI loop: exit status propagation, group output, behavior with zero files, the promo_redemption_concurrency.mjs step afterwards.
- Ratchet: false positives/negatives in its import detection; can a new source-only test evade it trivially (e.g. a dummy import)?

Rank findings by severity with file:line and a concrete failure. End with APPROVE or CHANGES REQUESTED.
