# CI configuration re-review: hither_app branch claude/b1-hygiene, round 4

Review only; do not modify files. Previous report: C:\Users\alex.shen\.claude\jobs\0e588e88\tmp\blocks\review-b1-r3b.out (one P2: the starting SHA was read from a file the first job could rewrite). Latest commit (`git diff HEAD~1..HEAD`) records the starting SHA as a step output before the assistant step, exposes it and a has_commits flag as job outputs, and the publish job reads `needs.claude.outputs.start_sha`; upload and publish are skipped when there are no commits.

Confirm or refute with file:line:
1. Is the P2 closed: can any later step in the first job change the value of `steps.start.outputs.sha` or the job output?
2. The has_commits gating: correct when the agent made zero commits, when the bundle step fails, and on reruns.
3. Any regression in the rest of `git diff origin/master...HEAD`.

End with APPROVE or CHANGES REQUESTED.
