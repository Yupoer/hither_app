# Code review: hither_app branch claude/b1-hygiene

You are reviewing, not fixing. Do not modify any file.

Diff to review: `git diff origin/master...HEAD` in this repo (one commit, "chore: remove committed agent state and tighten CI permissions").

Intent:
- Remove committed agent junk: .superpowers/ brainstorm state, apps/mobile/mcps/, apps/mobile/generate_report.js; ignore them.
- ci.yml: top-level `permissions: contents: read`; pin every action to a SHA on its current major. regen-ios-pods.yml: same.
- claude-fix.yml: narrow --allowedTools so the agent can branch, commit, push its branch and open a PR but cannot merge; fix Expo SDK version text.
- Rename expo-modules-core patch to the installed 57.0.21; pin @react-native-google-signin/google-signin to exactly 16.1.4.

Check:
1. Does any job in ci.yml need a token scope beyond contents: read that it no longer has (e.g. github-script steps that comment, pull-request reads)? Check each job and step.
2. Are the pinned SHAs real commits for the stated tags (use `gh api repos/<owner>/<repo>/commits/<tag> --jq .sha` if you can)?
3. Can claude-code-action still complete its job with the narrowed tool list (push its branch, create a PR)? Does the action push on its own? Any allowed pattern that still permits merging or force-push?
4. Is anything removed still referenced (EAS, scripts, docs, tests)? Is the new `mcps/` ignore too broad?
5. Patch rename: will patch-package apply it cleanly to 57.0.21 (compare patch context to node_modules/expo-modules-core)?

Report findings ranked by severity with file:line and a concrete failure scenario, or say none survive. End with a verdict: APPROVE or CHANGES REQUESTED.
