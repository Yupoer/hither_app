# Brief: which core operations still reach the v1 RPC, and does v3 handle them identically

Read-only investigation. Do not edit any file. Repo root is the worktree you were started in (hither_app). App code is in apps/mobile/src, SQL in supabase/migrations (apply in filename order).

## Question

`apps/mobile/src/api/services/CoreDataService.ts` `applyCoreOperation` sends an operation to `apply_core_operation_v3` only when `operation.actorId` is set (line ~70). Without an actorId, `record_arrival` goes to `set_destination_arrival_at`, `switch_gathering` goes to `apply_leader_gathering_switch`, and every other type goes to v1 `apply_core_operation` (lines 134-156).

Answer, with file:line citations for every claim:

1. Every production code path (not tests) that builds a `CoreOperation` and can reach `applyCoreOperation`. For each, is `actorId` always set, sometimes unset, or never set? Trace through the outbox (`coreOperationOutbox`, durable queue, sqlite persistence, migration of older persisted rows without actorId) and any factory such as `createCoreOperation`. Include persisted rows written by older app versions that lack actorId and are replayed after an OTA update.
2. The set of `operationType` values that can therefore reach v1 `apply_core_operation` (last full definition: supabase/migrations/20260919090000_unscheduled_destination_pool.sql:895, grants in 20260919120000_reconcile_out_of_order_security.sql:128-131). List which op types v1 accepts.
3. For each op type in (2): does v3 (`apply_core_operation_v3`, base 20260922000100_idempotent_navigation_end.sql plus replace() patches in 20261001115316, 20261002061447, 20261002113231, 20261004010000, 20261009132855) support it, and with the same semantics? Compare: authorization (role/scope/membership), version/conflict handling (v1 uses p_entity_version; v3 also uses p_sequence, p_dependency_ids, actor binding, operation_id replay), payload fields read, side effects, result shape (`status`, `entity_version`, `entity`, `effects`, `conflict.code`). Name every difference.
4. Which callers of the RPC names `apply_core_operation`, `apply_core_operation_v2`, `apply_core_operation_v3` exist anywhere in the repo besides CoreDataService (edge functions in supabase/functions, scripts, other SQL functions calling them).
5. Whether a client-side migration of the actorless path to v3 is possible: v3 requires `p_actor_id` = auth.uid(). If the actorless path could fill actorId from the current session user, would that change semantics (for example, replay of an old row by a different signed-in account)?

## Report

Plain markdown. Sections matching 1-5. Each claim cites file:line. End with a one-paragraph verdict: which op types (if any) can be moved to v3 with provably identical semantics, and what dropping v1/v2 server functions would require. Mark anything inferred rather than read as "inferred".
