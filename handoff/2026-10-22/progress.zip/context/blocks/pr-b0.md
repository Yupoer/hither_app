Brings the Expo SDK 57 packages up to the patch versions `expo install --check` expects. master CI has failed that check since 2026-10-16. The check runs before pgTAP, so no PR has executed the SQL suites in CI since then.

**Changes**
- Package bumps from `npx expo install --fix`: @expo/ui ~57.0.26, expo ~57.0.31, expo-auth-session ~57.0.16, expo-crypto ~57.0.4, expo-dev-client ~57.0.20, expo-location ~57.0.22, expo-notifications ~57.0.23, expo-updates ~57.0.26 and jest-expo ~57.0.6.
- expo-asset and expo-constants keep their existing ranges, which now resolve to 57.0.20 and 57.0.22. The lockfile is regenerated.
- `patches/expo-modules-core+57.0.24.patch`: the same EventEmitter.swift edit as before. That file is byte-identical in 57.0.20 and 57.0.24.
- `patches/expo-modules-jsi+57.1.3.patch`: only the JavaScriptActor.swift hunk remains.
  - Upstream 57.1.2 fixed the RuntimeScheduler and JavaScriptRuntime Swift 6.2 issues, so those hunks were dropped.
  - The patched JavaScriptActor.swift is byte-identical to what the old patch produced on 57.1.1.

**Release impact.** This PR changes native modules:
- Direct: @expo/ui, expo, expo-asset, expo-constants, expo-crypto, expo-dev-client, expo-location, expo-notifications, expo-updates.
- Transitive: expo-modules-core, expo-modules-jsi, expo-dev-launcher, expo-dev-menu, expo-linking.

A new native build is required before the next OTA. `runtimeVersion` in app.json is still the fixed "0.1.12". Bump it with the new build, or hold OTAs until that build ships, so existing 0.1.12 binaries don't receive JS built against the new native modules. `ios/Podfile.lock` refreshes on the next `pod install`, which cannot run on Windows.

**Verification**
Run from apps/mobile after a clean `npm ci`:
- patch-package applies all four patches with no warnings.
- `tsc --noEmit` exits 0.
- jest: 333 suites, 2787 tests pass.
- `test:meta` PASS.
- `verify:runtime` ok.
- `expo-doctor@1.20.4`: 20/20.
- `expo install --check`: up to date.
- The Swift patch has not been compiled locally. The macOS JSI jobs in CI cover it.

Closes #311

<!-- hither-test-meta parent: pure-chore -->

🤖 Generated with [Claude Code](https://claude.com/claude-code)
